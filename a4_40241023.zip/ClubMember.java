//----------------------------------------------
//Assignment 4
//Written by: (Om Hirlekar - 40241023)
//For Comp 248 Section CC - Summer 2024
//----------------------------------------------

import java.util.ArrayList;

public class ClubMember {
    private String firstName;
    private String lastName;
    private int birthYear;
    private int birthMonth;
    private int birthDay;
    private char gender;
    private String address;
    private String city;
    private String postalCode;
    private String phoneNumber;
    private int registrationNumber;
    private ArrayList<String> registeredPeriods;
    private FamilyMember familyMember;

    public ClubMember(FamilyMember familyMember, String firstName, String lastName, int birthYear, int birthMonth, int birthDay, char gender, 
                      String address, String city, String postalCode, String phoneNumber) {
        this.familyMember = familyMember;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthYear = birthYear;
        this.birthMonth = birthMonth;
        this.birthDay = birthDay;
        this.gender = gender;
        this.address = address;
        this.city = city;
        this.postalCode = postalCode;
        this.phoneNumber = phoneNumber;
        this.registrationNumber = (int)(Math.random() * 9000) + 1000;
        this.registeredPeriods = new ArrayList<>();
    }

    public FamilyMember getFamilyMember() { return familyMember; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public int getBirthYear() { return birthYear; }
    public void setBirthYear(int birthYear) { this.birthYear = birthYear; }

    public int getBirthMonth() { return birthMonth; }
    public void setBirthMonth(int birthMonth) { this.birthMonth = birthMonth; }

    public int getBirthDay() { return birthDay; }
    public void setBirthDay(int birthDay) { this.birthDay = birthDay; }

    public char getGender() { return gender; }
    public void setGender(char gender) { this.gender = gender; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getPostalCode() { return postalCode; }
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public int getRegistrationNumber() { return registrationNumber; }

    public ArrayList<String> getRegisteredPeriods() { return registeredPeriods; }

    public void addRegisteredPeriod(String period) {
        this.registeredPeriods.add(period);
    }
}
