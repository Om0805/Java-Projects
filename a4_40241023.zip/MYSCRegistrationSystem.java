//----------------------------------------------
//Assignment 4
//Written by: (Om Hirlekar - 40241023)
//For Comp 248 Section CC - Summer 2024
//----------------------------------------------

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class MYSCRegistrationSystem {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<ClubMember> members = new ArrayList<>();

        System.out.println("         Welcome to Montreal Youth Soccer Club (MYSC) Registration System");
        System.out.println("         ________________________________________________________________");
        System.out.println();

        while (members.size() < 20) {
            // Family Member Registration
            System.out.print("Please Enter Your Family Member's First Name and Last Name: ");
            String[] familyNames = getValidNames(scan);
            String familyFirstName = familyNames[0];
            String familyLastName = familyNames[1];
            
            System.out.println();
            System.out.println("Please Enter the Relationship between the family member and the new club member: ");
            System.out.println("            1 - Father\n            2 - Mother\n            3 - GrandFather\n            4 - GrandMother\n            5 - Tutor\n            6 - Partner\n            7 - Friend\n            8 - Other");
            System.out.println();
            System.out.print("Please Enter your choice (1-8): ");
            int relationshipChoice = getValidIntInput(scan, "Relationship", 1, 8);
            String relationship = getRelationship(relationshipChoice);

            System.out.println();
            System.out.print("Please Enter Your Address: ");
            String familyAddress = getValidStringInput(scan, "Address", 2);

            System.out.println();
            System.out.print("Please Enter Your City: ");
            String familyCity = getValidStringInput(scan, "City", 2);

            System.out.println();
            System.out.print("Please Enter Your Postal Code: ");
            String familyPostalCode = getValidStringInput(scan, "Postal Code", 6);

            System.out.println();
            System.out.print("Please Enter Your Phone Number: ");
            String familyPhoneNumber = getValidPhoneNumber(scan);

            FamilyMember familyMember = new FamilyMember(familyFirstName, familyLastName, relationship, familyAddress, familyCity, familyPostalCode, familyPhoneNumber);

            // Club Member Registration
            System.out.println();
            System.out.print("Please Enter the new club Member's First Name and Last Name: ");
            String[] memberNames = getValidNames(scan);
            String memberFirstName = memberNames[0];
            String memberLastName = memberNames[1];

            System.out.println();
            System.out.print("Please Enter the Year Of Birth between (2014 and 2020): ");
            int birthYear = getValidIntInput(scan, "Year Of Birth", 2014, 2020);

            System.out.println();
            System.out.print("Please Enter the Month Of Birth (1 - 12): ");
            int birthMonth = getValidIntInput(scan, "Month Of Birth", 1, 12);

            System.out.println();
            System.out.print("Please Enter the Day Of Birth (1 - 31): ");
            int birthDay = getValidIntInput(scan, "Day Of Birth", 1, 31);

            System.out.println();
            System.out.print("Please Enter the Gender Of the new club member (M/F): ");
            char gender = getValidGender(scan);

            System.out.println();
            System.out.print("Please Enter new club member's Address: ");
            String memberAddress = getValidStringInput(scan, "Address", 2);

            System.out.println();
            System.out.print("Please Enter new club member's City: ");
            String memberCity = getValidStringInput(scan, "City", 2);

            System.out.println();
            System.out.print("Please Enter new club member's Postal Code: ");
            String memberPostalCode = getValidStringInput(scan, "Postal Code", 6);

            System.out.println();
            System.out.print("Please Enter new club member's Phone Number: ");
            String memberPhoneNumber = getValidPhoneNumber(scan);

            ClubMember clubMember = new ClubMember(familyMember, memberFirstName, memberLastName, birthYear, birthMonth, birthDay, gender, memberAddress, memberCity, memberPostalCode, memberPhoneNumber);

            // Registering for Periods
            System.out.println();
            int totalCost = 0;
            while (true) {
                System.out.println("         Summer of 2024 Tournaments Registration");
                System.out.println("         _______________________________________");
                String[] periods = {"Period 1: June 3-28", "Period 2: July 1-26", "Period 3: August 5-30"};
                for (int i = 0; i < periods.length; i++) {
                    if (!clubMember.getRegisteredPeriods().contains(periods[i])) {
                        System.out.printf("       %d - %s\n", i + 1, periods[i]);
                    }
                }

                System.out.println();
                System.out.print("Do you wish to Register " + clubMember.getFirstName() + " with Summer Registration (yes/no) ? ");
                String registerChoice = scan.nextLine().trim().toLowerCase();
                if (registerChoice.equals("yes")) {
                    System.out.print("Please Enter your choice: ");
                    int periodChoice = getValidIntInput(scan, "Period", 1, periods.length);
                    String selectedPeriod = periods[periodChoice - 1];
                    clubMember.addRegisteredPeriod(selectedPeriod);
                    totalCost += 100;
                } else {
                    System.out.printf("%s %s do not have any Summer 2024 Tournament registration.\n", clubMember.getFirstName(), clubMember.getLastName());
                    break;
                }

                System.out.println();
                System.out.print("Do you wish to add more periods to the registration (yes/no) ? ");
                String addAnother = scan.nextLine().trim().toLowerCase();
                if (!addAnother.equals("yes")) {
                    break;
                }
            }

            members.add(clubMember);

            System.out.println();
            System.out.println("__________________________________________");
            System.out.printf("%s %s is successfully registered in the following 2024 Summer Tournaments:\n", clubMember.getFirstName(), clubMember.getLastName());
            for (String period : clubMember.getRegisteredPeriods()) {
                System.out.println(period);
            }
            System.out.printf("The total Cost of the tournaments registrations is: %.2f $\n", (double) totalCost);
            System.out.print("Do you wish to add more members to the club (yes/no) ? ");
            String addAnother = scan.nextLine().trim().toLowerCase();
            if (!addAnother.equals("yes")) {
                break;
            }
        }

        // Final Output
        printFinalOutput(members);
        scan.close();
    }

    // Method to print final output
    private static void printFinalOutput(ArrayList<ClubMember> members) {
        System.out.println("-----------------------------------------------------------");
        System.out.println("Montreal Youth Soccer Club (MYSC) have " + members.size() + " New Registrations:");
        System.out.println("-----------------------------------------------------------");
        int memberCount = 1;
        
        for (ClubMember member : members) {
            FamilyMember familyMember = member.getFamilyMember();
            System.out.println();
            System.out.println("     _______________________________________");
            System.out.println("     New Club Member " + memberCount + " Registration Details.");
            System.out.println("     ________________________________________");
            System.out.printf("     %s %s %s of the new MYSC club member %s %s with new MYSC club membership # %s\n",
                    familyMember.getFirstName(), familyMember.getLastName(), familyMember.getRelationship(),
                    member.getFirstName(), member.getLastName(), member.getRegistrationNumber());
            System.out.printf("     Lives at: %s in the city of %s with postal code %s\n",
                    familyMember.getAddress(), familyMember.getCity(), familyMember.getPostalCode());
            System.out.printf("     Has the following Telephone Number: %s\n", familyMember.getPhoneNumber());
            System.out.printf("     The new club member %s %s who lives at: %s in the city of %s with postal code %s\n",
                    member.getFirstName(), member.getLastName(), member.getAddress(), member.getCity(), member.getPostalCode());
            System.out.printf("     Has the following Telephone Number: %s is successfully added to the MYSC %s teams.\n",
                    member.getPhoneNumber(), member.getGender() == 'M' ? "Boys" : "Girls");
            System.out.println();
            memberCount++;
        }

        // Sorting members by first and last names.
        Collections.sort(members, new Comparator<ClubMember>() {
            public int compare(ClubMember m1, ClubMember m2) {
                int firstNameComparison = m1.getFirstName().compareTo(m2.getFirstName());
                if (firstNameComparison == 0) {
                    return m1.getLastName().compareTo(m2.getLastName());
                } else {
                    return firstNameComparison;
                }
            }
        });

        // Displaying the new members.
        System.out.println("-----------------------------------------------------------");
        System.out.println("Following is the list of the new Members:");
        System.out.println("-----------------------------------------------------------");
        for (ClubMember member : members) {
            System.out.printf("%s %s\n", member.getFirstName(), member.getLastName());
        }

        // Finding the youngest and oldest members.
        ClubMember youngestMember = members.get(0);
        ClubMember oldestMember = members.get(0);
        
        for (ClubMember member : members) {
            if (isYounger(member, youngestMember)) {
                youngestMember = member;
            }

            if (isOlder(member, oldestMember)) {
                oldestMember = member;
            }
        }
        
        System.out.printf("The Youngest new club member who is born on %d/%d/%d is: %s %s\n",
                youngestMember.getBirthDay(), youngestMember.getBirthMonth(), youngestMember.getBirthYear(),
                youngestMember.getFirstName(), youngestMember.getLastName());
        System.out.printf("The Oldest new club member who is born on %d/%d/%d is: %s %s\n",
                oldestMember.getBirthDay(), oldestMember.getBirthMonth(), oldestMember.getBirthYear(),
                oldestMember.getFirstName(), oldestMember.getLastName());

        System.out.println("____________________________________________");
        System.out.println("Thank you for using our Registration System");
        System.out.println("____________________________________________");
    }

    private static boolean isYounger(ClubMember m1, ClubMember m2) {
        if (m1.getBirthYear() > m2.getBirthYear()) return true;
        if (m1.getBirthYear() == m2.getBirthYear() && m1.getBirthMonth() > m2.getBirthMonth()) return true;
        return m1.getBirthYear() == m2.getBirthYear() && m1.getBirthMonth() == m2.getBirthMonth() && m1.getBirthDay() > m2.getBirthDay();
    }

    private static boolean isOlder(ClubMember m1, ClubMember m2) {
        if (m1.getBirthYear() < m2.getBirthYear()) return true;
        if (m1.getBirthYear() == m2.getBirthYear() && m1.getBirthMonth() < m2.getBirthMonth()) return true;
        return m1.getBirthYear() == m2.getBirthYear() && m1.getBirthMonth() == m2.getBirthMonth() && m1.getBirthDay() < m2.getBirthDay();
    }

    // Validation methods (same as your original implementation)
    private static String[] getValidNames(Scanner scanner) {
        String[] names;
        while (true) {
            String input = scanner.nextLine().trim();
            names = input.split(" ");
            if (names.length == 2 && names[0].length() >= 2 && names[1].length() >= 2) {
                break;
            }
            System.out.printf("Invalid First Name or Last Name: %s\n", input);
            System.out.println("First Name and Last Name should each have at least two characters.");
        }
        return names;
    }

    private static String getValidStringInput(Scanner scan, String inputType, int minLength) {
        String input;
        while (true) {
            input = scan.nextLine().trim();
            if (input.length() >= minLength) {
                break;
            }
            System.out.printf("Invalid %s: %s\n", inputType, input);
            System.out.printf("%s should have at least %d characters.\n", inputType, minLength);
        }
        return input;
    }

    private static int getValidIntInput(Scanner scan, String inputType, int minValue, int maxValue) {
        int input;
        while (true) {
            input = scan.nextInt();
            scan.nextLine();
            if (input >= minValue && input <= maxValue) {
                break;
            }
            System.out.printf("Invalid %s: %d\n", inputType, input);
            System.out.printf("Valid %s between %d and %d\n", inputType, minValue, maxValue);
        }
        return input;
    }

    private static String getValidPhoneNumber(Scanner scanner) {
        String input;
        while (true) {
            input = scanner.nextLine().trim();
            if (input.matches("\\d{3}-\\d{3}-\\d{4}")) {
                break;
            }
            System.out.printf("Invalid Phone Number: %s\n", input);
            System.out.println("Valid Phone Number contains at least 10 digits in the format XXX-XXX-XXXX.");
        }
        return input;
    }

    private static char getValidGender(Scanner scanner) {
        char input;
        while (true) {
            input = scanner.nextLine().trim().toUpperCase().charAt(0);
            if (input == 'M' || input == 'F') {
                break;
            }
            System.out.printf("Invalid Gender: %c\n", input);
            System.out.println("Valid Gender is either 'M' for Male or 'F' for Female.");
        }
        return input;
    }

    private static String getRelationship(int choice) {
        switch (choice) {
            case 1: return "Father";
            case 2: return "Mother";
            case 3: return "GrandFather";
            case 4: return "GrandMother";
            case 5: return "Tutor";
            case 6: return "Partner";
            case 7: return "Friend";
            case 8: return "Other";
            default: return "Unknown";
        }
    }
}

/* SAMPLE OUTPUT.

Welcome to Montreal Youth Soccer Club (MYSC) Registration System
________________________________________________________________

Please Enter Your Family Member's First Name and Last Name: OM HIRLEKAR

Please Enter the Relationship between the family member and the new club member: 
   1 - Father
   2 - Mother
   3 - GrandFather
   4 - GrandMother
   5 - Tutor
   6 - Partner
   7 - Friend
   8 - Other

Please Enter your choice (1-8): 7

Please Enter Your Address: 1001 RUE LUCIEN-L'ALLIER

Please Enter Your City: MONTREAL

Please Enter Your Postal Code: H3G 0G7

Please Enter Your Phone Number: 654-879-9988

Please Enter the new club Member's First Name and Last Name: ASHWITA POKALA

Please Enter the Year Of Birth between (2014 and 2020): 2020

Please Enter the Month Of Birth (1 - 12): 11

Please Enter the Day Of Birth (1 - 31): 21

Please Enter the Gender Of the new club member (M/F): F

Please Enter new club member's Address: 415 PEEL STREET

Please Enter new club member's City: MONTREAL

Please Enter new club member's Postal Code: HG3 GH6

Please Enter new club member's Phone Number: 653-737-8383

Summer of 2024 Tournaments Registration
_______________________________________
1 - Period 1: June 3-28
2 - Period 2: July 1-26
3 - Period 3: August 5-30

Do you wish to Register ASHWITA with Summer Registration (yes/no) ? YES
Please Enter your choice: 1

Do you wish to add more periods to the registration (yes/no) ? YES
Summer of 2024 Tournaments Registration
_______________________________________
2 - Period 2: July 1-26
3 - Period 3: August 5-30

Do you wish to Register ASHWITA with Summer Registration (yes/no) ? YES
Please Enter your choice: 2

Do you wish to add more periods to the registration (yes/no) ? YES
Summer of 2024 Tournaments Registration
_______________________________________
3 - Period 3: August 5-30

Do you wish to Register ASHWITA with Summer Registration (yes/no) ? YES
Please Enter your choice: 3

Do you wish to add more periods to the registration (yes/no) ? NO

__________________________________________
ASHWITA POKALA is successfully registered in the following 2024 Summer Tournaments:
Period 1: June 3-28
Period 2: July 1-26
Period 3: August 5-30
The total Cost of the tournaments registrations is: 300.00 $
Do you wish to add more members to the club (yes/no) ? YES
Please Enter Your Family Member's First Name and Last Name: SHETTY BANDAVYA

Please Enter the Relationship between the family member and the new club member: 
   1 - Father
   2 - Mother
   3 - GrandFather
   4 - GrandMother
   5 - Tutor
   6 - Partner
   7 - Friend
   8 - Other

Please Enter your choice (1-8): 7

Please Enter Your Address: 1002 PIE IX

Please Enter Your City: MONTREAL

Please Enter Your Postal Code: GH4 GH6

Please Enter Your Phone Number: 555-373-8388

Please Enter the new club Member's First Name and Last Name: SURABHI PATEL

Please Enter the Year Of Birth between (2014 and 2020): 2014

Please Enter the Month Of Birth (1 - 12): 10

Please Enter the Day Of Birth (1 - 31): 30

Please Enter the Gender Of the new club member (M/F): F

Please Enter new club member's Address: 12345 SHERBROOK CITY

Please Enter new club member's City: MONTREAL

Please Enter new club member's Postal Code: GH3 F53

Please Enter new club member's Phone Number: 542-762-2222

Summer of 2024 Tournaments Registration
_______________________________________
1 - Period 1: June 3-28
2 - Period 2: July 1-26
3 - Period 3: August 5-30

Do you wish to Register SURABHI with Summer Registration (yes/no) ? YES
Please Enter your choice: 2

Do you wish to add more periods to the registration (yes/no) ? YES
Summer of 2024 Tournaments Registration
_______________________________________
1 - Period 1: June 3-28
3 - Period 3: August 5-30

Do you wish to Register SURABHI with Summer Registration (yes/no) ? YES
Please Enter your choice: 1

Do you wish to add more periods to the registration (yes/no) ? YES
Summer of 2024 Tournaments Registration
_______________________________________
3 - Period 3: August 5-30

Do you wish to Register SURABHI with Summer Registration (yes/no) ? YES
Please Enter your choice: 3

Do you wish to add more periods to the registration (yes/no) ? NO

__________________________________________
SURABHI PATEL is successfully registered in the following 2024 Summer Tournaments:
Period 2: July 1-26
Period 1: June 3-28
Period 3: August 5-30
The total Cost of the tournaments registrations is: 300.00 $
Do you wish to add more members to the club (yes/no) ? NO
-----------------------------------------------------------
Montreal Youth Soccer Club (MYSC) have 2 New Registrations:
-----------------------------------------------------------

_______________________________________
New Club Member 1 Registration Details.
________________________________________
OM HIRLEKAR Friend of the new MYSC club member ASHWITA POKALA with new MYSC club membership # 5081
Lives at: 1001 RUE LUCIEN-L'ALLIER in the city of MONTREAL with postal code H3G 0G7
Has the following Telephone Number: 654-879-9988
The new club member ASHWITA POKALA who lives at: 415 PEEL STREET in the city of MONTREAL with postal code HG3 GH6
Has the following Telephone Number: 653-737-8383 is successfully added to the MYSC Girls teams.


_______________________________________
New Club Member 2 Registration Details.
________________________________________
SHETTY BANDAVYA Friend of the new MYSC club member SURABHI PATEL with new MYSC club membership # 5836
Lives at: 1002 PIE IX in the city of MONTREAL with postal code GH4 GH6
Has the following Telephone Number: 555-373-8388
The new club member SURABHI PATEL who lives at: 12345 SHERBROOK CITY in the city of MONTREAL with postal code GH3 F53
Has the following Telephone Number: 542-762-2222 is successfully added to the MYSC Girls teams.

-----------------------------------------------------------
Following is the list of the new Members:
-----------------------------------------------------------
ASHWITA POKALA
SURABHI PATEL
The Youngest new club member who is born on 21/11/2020 is: ASHWITA POKALA
The Oldest new club member who is born on 30/10/2014 is: SURABHI PATEL
____________________________________________
Thank you for using our Registration System */