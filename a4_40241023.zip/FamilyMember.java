//----------------------------------------------
//Assignment 4
//Written by: (Om Hirlekar - 40241023)
//For Comp 248 Section CC - Summer 2024
//----------------------------------------------

public class FamilyMember {
    private String firstName;
    private String lastName;
    private String relationship;
    private String address;
    private String city;
    private String postalCode;
    private String phoneNumber;

    public FamilyMember(String firstName, String lastName, String relationship, String address, String city, String postalCode, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.relationship = relationship;
        this.address = address;
        this.city = city;
        this.postalCode = postalCode;
        this.phoneNumber = phoneNumber;
    }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getRelationship() { return relationship; }
    public void setRelationship(String relationship) { this.relationship = relationship; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getPostalCode() { return postalCode; }
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
}