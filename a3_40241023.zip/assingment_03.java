import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.Comparator;
public class assingment_03 {
	
	
	
	private static String[] getValidNames(Scanner scanner) {
        String[] names;
        while (true) {
            String input = scanner.nextLine().trim();
            names = input.split(" ");
            if (names.length == 2 && names[0].length() >= 2 && names[1].length() >= 2) {
                break;
            }
            System.out.printf("Invalid First Name or Last Name: %s\n", input);
            System.out.println("First Name and Last Name should each have at least two characters.");
        }
        return names;
        
	}

	// For minimum 2 character first and last name
	
	private static String getValidStringInput(Scanner scan, String inputType, int minLength) {
		// TODO Auto-generated method stub
		String input;
		while (true) {
			input = scan.nextLine().trim();
			if (input.length() >= minLength) {
				break;
			}
			System.out.printf("Invalid %s: %s\n" ,  inputType, input);
			System.out.printf("%s should have at least %d characters.\n", inputType, minLength);
		}
		return input;
	
	
	}
	
	//For invalid Names:
	
	private static int getValidIntInput(Scanner scan, String inputType, int minValue, int maxValue) {
		// TODO Auto-generated method stub
		int input;
		while (true) {
			input = scan.nextInt();
			scan.nextLine();
			if (input >= minValue && input <= maxValue) {
				break;
			}
			System.out.printf("Invalid %s: %d\n",  inputType, input);
			System.out.printf("Valid %s between %d and %d\n", inputType, minValue, maxValue);
		}
		return input;
	}
	
	private static String getRelationship(int choice) {
        switch (choice) {
            case 1: return "Father";
            case 2: return "Mother";
            case 3: return "GrandFather";
            case 4: return "GrandMother";
            case 5: return "Tutor";
            case 6: return "Partner";
            case 7: return "Friend";
            case 8: return "Other";
            default: return "Unknown";
        }
        }
	
	// For Valid Phone Number
	
	private static String getValidPhoneNumber(Scanner scanner) {
        String input;
        while (true) {
            input = scanner.nextLine().trim();
            if (input.matches("\\d{3}-\\d{3}-\\d{4}")) {
                break;
            }
            System.out.printf("Invalid Phone Number: %s\n", input);
            System.out.println("Valid Phone Number contains at least 10 digits in the format XXX-XXX-XXXX.");
        }
        return input;
    }
	
	// For Valid Gender:
	
	private static char getValidGender(Scanner scanner) {
        char input;
        while (true) {
            input = scanner.nextLine().trim().toUpperCase().charAt(0);
            if (input == 'M' || input == 'F') {
                break;
            }
            System.out.printf("Invalid Gender: %c\n", input);
            System.out.println("Valid Gender is either 'M' for Male or 'F' for Female.");
        }
        return input;
    }

	public static void main(String[] args) {
		
Scanner scan = new Scanner(System.in);
		
		
		//Prompt inputs for user
		
		ArrayList<ArrayList<String>> members = new ArrayList<>();
       
		System.out.println("         Welcome to Montreal Youth Soccer Club (MYSC) Registration System");
		System.out.println("         ________________________________________________________________");
		System.out.println();
		
		while (members.size() <= 20) {
			if (members.size() >= 20) {
                System.out.println("Maximum registration limit reached.");
                break;
            }
			
			System.out.print("Please Enter Your Family Member's First Name and Last Name: ");
    		String[] familyNames = getValidNames(scan);
            String familyFirstName = familyNames[0];
            String familyLastName = familyNames[1];
            System.out.println();
            
            System.out.println("Please Enter the Relationship between the family member and the new club member: ");
            System.out.println("            1 - Father\n            2 - Mother\n            3 - GrandFather\n            4 - GrandMother\n            5 - Tutor\n            6 - Partner\n            7 - Friend\n            8 - other");
            System.out.print("PleaseEnter your choice (1-8): ");
            int relationshipChoice = getValidIntInput(scan, "Relationship", 1, 8);
            String relationship = getRelationship(relationshipChoice);
            System.out.println();

            System.out.print("Please Enter Your Address: ");
            String familyAddress = getValidStringInput(scan, "Address", 2);
            System.out.println();
            
            System.out.print("Please Enter Your City: ");
            String familyCity = getValidStringInput(scan, "City", 2);
            System.out.println();
            
            System.out.print("Please Enter Your Postal Code: ");
            String familyPostalCode = getValidStringInput(scan, "Postal Code", 6);
            System.out.println();
            
            System.out.print("Please Enter Your Phone Number: ");
            String familyPhoneNumber = getValidPhoneNumber(scan);
            System.out.println();

            // Details of new Members
            System.out.print("Please Enter the new club Member's First Name and Last Name: ");
            String[]memberNames = getValidNames(scan);        
            String memberFirstName = memberNames[0];
            String memberLastName = memberNames[1];
            System.out.println();
            
            System.out.print("Please Enter the Year Of Birth (2014 and 2024): ");
            int birthYear = getValidIntInput(scan, "Year Of Birth", 2014, 2024);
            System.out.println();
            
            System.out.print("Please Enter the Month Of Birth (1 - 12): ");
            int birthMonth = getValidIntInput(scan, "Month Of Birth", 1, 12);
            System.out.println();
            
            System.out.print("Please Enter the Day Of Birth (1 - 31): ");
            int birthDay = getValidIntInput(scan, "Day Of Birth", 1, 31);
            System.out.println();

            System.out.print("Please Enter the Gender Of the new club member (M/F): ");
            char gender = getValidGender(scan);
            System.out.println();

            System.out.print("Please Enter new club member's Address: ");
            String memberAddress = getValidStringInput(scan, "Address", 2);
            System.out.println();
            
            System.out.print("Please Enter new club member's City: ");
            String memberCity = getValidStringInput(scan, "City", 2);
            System.out.println();
            
            System.out.print("Please Enter new club member's Postal Code: ");
            String memberPostalCode = getValidStringInput(scan, "Postal Code", 6);
            System.out.println();
            
            System.out.print("Please Enter new club member's Phone Number: ");
            String memberPhoneNumber = getValidPhoneNumber(scan);
            System.out.println();
            
           // Random registration number generator:
            
            int registrationNumber = (int)(Math.random() * 9000) + 1000;
            
            
            // Array String for Periods.
            
            ArrayList<String> registeredPeriods = new ArrayList<>();
            int totalCost = 0;
            
            while (true) {
            	System.out.println("         Summer of 2024 Tournaments Registration");
                System.out.println("         _______________________________________");
               
                System.out.println("Periods Available to register your child: ");
                String[] periods = {"Period 1: June 3-28", "Period 2: July 1-26", "Period 3: August 5-30"};
                for (int i = 0; i < periods.length; i++) {
                	if (!registeredPeriods.contains(periods[i])) {
                		System.out.printf("       %d - %s\n", i + 1, periods[i]);
                	}
                }
                
                System.out.println();
                
                System.out.print("Do you wish to Register " + memberFirstName + " with Summer Registration (yes/no) ? ");
                String registerChoice = scan.nextLine().trim().toLowerCase();
                if (registerChoice.equals("yes")) {
                	System.out.print("Please Enter your choice: ");
                    int periodChoice = getValidIntInput(scan, "Period", 1, periods.length);
                    String selectedPeriod = periods[periodChoice - 1];
                    System.out.println();
                    
                    if (!registeredPeriods.contains(selectedPeriod)) {
                    	
                    	registeredPeriods.add(selectedPeriod);
                        totalCost += 100;
                    } else {
                    	System.out.printf("The new member is already registered in %s.\n", selectedPeriod);
                    }
                } else {
                	System.out.printf("%s %s do not have any Summer 2024 Tournament registration.\n", memberFirstName, memberLastName);
                }
                System.out.print("Do you wish to add more periods to the registration (yes/no) ? ");
                String addanother = scan.nextLine().trim().toLowerCase();
                if (!addanother.equals("yes")) {
                	 break;
                }
            }
            
            // Array List for New Member Data to be used while final output.
            
            ArrayList<String> NewMemberData = new ArrayList<>();
             NewMemberData.add(familyFirstName);
             NewMemberData.add(familyLastName);
             NewMemberData.add(relationship);
             NewMemberData.add(familyAddress);
             NewMemberData.add(familyCity);
             NewMemberData.add(familyPostalCode);
             NewMemberData.add(familyPhoneNumber);
             NewMemberData.add(memberFirstName);
             NewMemberData.add(memberLastName);
             NewMemberData.add(String.valueOf(birthYear));
             NewMemberData.add(String.valueOf(birthMonth));
             NewMemberData.add(String.valueOf(birthDay));
             NewMemberData.add(String.valueOf(gender));
             NewMemberData.add(memberAddress);
             NewMemberData.add(memberCity);
             NewMemberData.add(memberPostalCode);
             NewMemberData.add(memberPhoneNumber);
             NewMemberData.add(String.valueOf(registrationNumber));
             NewMemberData.addAll(registeredPeriods);
             members.add(NewMemberData);
             
             
             System.out.println();
             System.out.println();
             

             // Final Registration output:
             
             System.out.println("__________________________________________");
             System.out.printf("%s %s is successfully registered in the following 2024 Summer Tournaments:\n", memberFirstName, memberLastName);
             for (String period : registeredPeriods) {
            	 System.out.println(period);
             }
             
             System.out.printf("The total Cost of the tournaments registrations is: %.2f $\n", (double) totalCost);
             
             System.out.print("Do you wish to add more members to the club (yes/no) ? ");
             String addAnother = scan.nextLine().trim().toLowerCase();
             if (!addAnother.equals("yes")) {
            	 break;
             }
			
		}
		
		 // Final Output    
        System.out.println("-----------------------------------------------------------");
        System.out.println("Montreal Youth Soccer Club (MYSC) have " + members.size() + " New Registrations:");
        System.out.println("-----------------------------------------------------------");
        int memberCount = 1;
        
        for (ArrayList<String> member : members) {
        	System.out.println();
            System.out.println("     _______________________________________");
            System.out.println("     New Club Member " + memberCount + " Registration Details.");
            System.out.println("     ________________________________________");
            System.out.printf("     %s %s %s of the new MYSC club member %s %s with new MYSC club membership # %s\n",
                    member.get(0), member.get(1), member.get(2), member.get(7), member.get(8), member.get(17));
            System.out.printf("     Lives at: %s in the city of %s with postal code %s\n",
                    member.get(3), member.get(4), member.get(5));
            System.out.printf("     Has the following Telephone Number: %s\n", member.get(6));
            System.out.println();
            
            System.out.printf("     The new club member %s %s who lives at: %s in the city of %s with postal code %s\n",
                    member.get(7), member.get(8), member.get(13), member.get(14), member.get(15));
            System.out.printf("     Has the following Telephone Number: %s is successfully added to the MYSC %s teams.\n",
                    member.get(16), member.get(12).equals("M") ? "Boys" : "Girls");
            System.out.println();
            memberCount++;
        }
		
		
		// Sorting members by first and last names.
        Collections.sort(members, new Comparator<ArrayList<String>>() {
            public int compare(ArrayList<String> m1, ArrayList<String> m2) {
                int firstNameComparison = m1.get(7).compareTo(m2.get(7));
                if (firstNameComparison == 0) {
                    return m1.get(8).compareTo(m2.get(8));
                } else {
                    return firstNameComparison;
                }
            }
        });
        
        // Displaying the new members.
        System.out.println("-----------------------------------------------------------");
        System.out.println("Following is the list of the new Members:");
        System.out.println("-----------------------------------------------------------");
        for (ArrayList<String> member : members) {
            System.out.printf("%s %s\n", member.get(7), member.get(8));
        }

        // Finding the youngest and oldest members.
        ArrayList<String> youngestMember = members.get(0);
        ArrayList<String> oldestMember = members.get(0);
        
        for (ArrayList<String> member : members) {
            int birthYear = Integer.parseInt(member.get(9));
            int birthMonth = Integer.parseInt(member.get(10));
            int birthDay = Integer.parseInt(member.get(11));
            int youngestYear = Integer.parseInt(youngestMember.get(9));
            int youngestMonth = Integer.parseInt(youngestMember.get(10));
            int youngestDay = Integer.parseInt(youngestMember.get(11));
            int oldestYear = Integer.parseInt(oldestMember.get(9));
            int oldestMonth = Integer.parseInt(oldestMember.get(10));
            int oldestDay = Integer.parseInt(oldestMember.get(11));
            
            if (birthYear > youngestYear ||
                    (birthYear == youngestYear && birthMonth > youngestMonth) ||
                    (birthYear == youngestYear && birthMonth == youngestMonth && birthDay > youngestDay)) {
                youngestMember = member;
            }

            if (birthYear < oldestYear ||
                    (birthYear == oldestYear && birthMonth < oldestMonth) ||
                    (birthYear == oldestYear && birthMonth == oldestMonth && birthDay < oldestDay)) {
                oldestMember = member;
            }
        }

        System.out.println();
        System.out.printf("The Youngest new club member who is born on %s/%s/%s is: %s %s\n",
                youngestMember.get(11), youngestMember.get(10), youngestMember.get(9),
                youngestMember.get(7), youngestMember.get(8));
        System.out.printf("The Oldest new club member who is born on %s/%s/%s is: %s %s\n",
                oldestMember.get(11), oldestMember.get(10), oldestMember.get(9),
                oldestMember.get(7), oldestMember.get(8));
        
        scan.close();

	}

}

// SAMPLE OUTPUT:

/*
 *
 * Welcome to Montreal Youth Soccer Club (MYSC) Registration System
         ________________________________________________________________

Please Enter Your Family Member's First Name and Last Name: Om hirlekar

Please Enter the Relationship between the family member and the new club member: 
            1 - Father
            2 - Mother
            3 - GrandFather
            4 - GrandMother
            5 - Tutor
            6 - Partner
            7 - Friend
            8 - other
PleaseEnter your choice (1-8): 7

Please Enter Your Address: 1003 rue lucien

Please Enter Your City: montreal

Please Enter Your Postal Code: H5G 7H7

Please Enter Your Phone Number: 543-945-444
Invalid Phone Number: 543-945-444
Valid Phone Number contains at least 10 digits in the format XXX-XXX-XXXX.
567-666-7777

Please Enter the new club Member's First Name and Last Name: ASHWITA POKALA

Please Enter the Year Of Birth (2014 and 2024): 2020

Please Enter the Month Of Birth (1 - 12): 11

Please Enter the Day Of Birth (1 - 31): 21

Please Enter the Gender Of the new club member (M/F): F

Please Enter new club member's Address: 1003 PEEL STREET

Please Enter new club member's City: MONTREAL

Please Enter new club member's Postal Code: G5H 8H8]

Please Enter new club member's Phone Number: 645-746-4444

         Summer of 2024 Tournaments Registration
         _______________________________________
Periods Available to register your child: 
       1 - Period 1: June 3-28
       2 - Period 2: July 1-26
       3 - Period 3: August 5-30

Do you wish to Register ASHWITA with Summer Registration (yes/no) ? YES
Please Enter your choice: 1

Do you wish to add more periods to the registration (yes/no) ? YES
         Summer of 2024 Tournaments Registration
         _______________________________________
Periods Available to register your child: 
       2 - Period 2: July 1-26
       3 - Period 3: August 5-30

Do you wish to Register ASHWITA with Summer Registration (yes/no) ? YES
Please Enter your choice: 2

Do you wish to add more periods to the registration (yes/no) ? NO


__________________________________________
ASHWITA POKALA is successfully registered in the following 2024 Summer Tournaments:
Period 1: June 3-28
Period 2: July 1-26
The total Cost of the tournaments registrations is: 200.00 $
Do you wish to add more members to the club (yes/no) ? YES
Please Enter Your Family Member's First Name and Last Name: JOE BIDEN

Please Enter the Relationship between the family member and the new club member: 
            1 - Father
            2 - Mother
            3 - GrandFather
            4 - GrandMother
            5 - Tutor
            6 - Partner
            7 - Friend
            8 - other
PleaseEnter your choice (1-8): 1

Please Enter Your Address: 19765 MUMBAI

Please Enter Your City: MUMBAI

Please Enter Your Postal Code: 400605

Please Enter Your Phone Number: 567-444-3434

Please Enter the new club Member's First Name and Last Name: BAANDAVYA LAHARI

Please Enter the Year Of Birth (2014 and 2024): 2015

Please Enter the Month Of Birth (1 - 12): 5

Please Enter the Day Of Birth (1 - 31): 25

Please Enter the Gender Of the new club member (M/F): F

Please Enter new club member's Address: 1234 THANE

Please Enter new club member's City: THANE

Please Enter new club member's Postal Code: G5H GH5

Please Enter new club member's Phone Number: 456-345-2323

         Summer of 2024 Tournaments Registration
         _______________________________________
Periods Available to register your child: 
       1 - Period 1: June 3-28
       2 - Period 2: July 1-26
       3 - Period 3: August 5-30

Do you wish to Register BAANDAVYA with Summer Registration (yes/no) ? YES
Please Enter your choice: 3

Do you wish to add more periods to the registration (yes/no) ? YES
         Summer of 2024 Tournaments Registration
         _______________________________________
Periods Available to register your child: 
       1 - Period 1: June 3-28
       2 - Period 2: July 1-26

Do you wish to Register BAANDAVYA with Summer Registration (yes/no) ? YES
Please Enter your choice: 2

Do you wish to add more periods to the registration (yes/no) ? NO


__________________________________________
BAANDAVYA LAHARI is successfully registered in the following 2024 Summer Tournaments:
Period 3: August 5-30
Period 2: July 1-26
The total Cost of the tournaments registrations is: 200.00 $
Do you wish to add more members to the club (yes/no) ? NO
-----------------------------------------------------------
Montreal Youth Soccer Club (MYSC) have 2 New Registrations:
-----------------------------------------------------------

     _______________________________________
     New Club Member 1 Registration Details.
     ________________________________________
     Om hirlekar Friend of the new MYSC club member ASHWITA POKALA with new MYSC club membership # 6827
     Lives at: 1003 rue lucien in the city of montreal with postal code H5G 7H7
     Has the following Telephone Number: 567-666-7777

     The new club member ASHWITA POKALA who lives at: 1003 PEEL STREET in the city of MONTREAL with postal code G5H 8H8]
     Has the following Telephone Number: 645-746-4444 is successfully added to the MYSC Girls teams.


     _______________________________________
     New Club Member 2 Registration Details.
     ________________________________________
     JOE BIDEN Father of the new MYSC club member BAANDAVYA LAHARI with new MYSC club membership # 5492
     Lives at: 19765 MUMBAI in the city of MUMBAI with postal code 400605
     Has the following Telephone Number: 567-444-3434

     The new club member BAANDAVYA LAHARI who lives at: 1234 THANE in the city of THANE with postal code G5H GH5
     Has the following Telephone Number: 456-345-2323 is successfully added to the MYSC Girls teams.

-----------------------------------------------------------
Following is the list of the new Members:
-----------------------------------------------------------
ASHWITA POKALA
BAANDAVYA LAHARI

The Youngest new club member who is born on 21/11/2020 is: ASHWITA POKALA
The Oldest new club member who is born on 25/5/2015 is: BAANDAVYA LAHARI

*/
