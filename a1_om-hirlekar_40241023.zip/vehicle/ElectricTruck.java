//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

package vehicle;

/*
 * Represents an electric truck with a maximum load capacity and autonomy (range).
 * it also Inherits common truck attributes from the Truck class.
 */

/* will create a counter specially for electric truck which
* will start from initials "ET" which represents electric truck.
* 
* to make it more readable and clear to understand 
* we will start the ET counter from "1101"
*/

public class ElectricTruck extends Truck {
    private static int etCounter = 1101; 
    private double maxAutonomy; 
    
 /*
 * Parameterized constructor for ElectricTruck.
 */
    
    public ElectricTruck(String make, String model, int yearOfProduction, double maxCapacity, double maxAutonomy) {
        super(make, model, yearOfProduction, maxCapacity);
        
        /* We will increment the ET counter after each assigned 
         * ET Truck, so it will be unique for each ET TRUCK.
         */
        this.platenumber = "ET" + etCounter++; 
        this.maxAutonomy = maxAutonomy;
    }

    /*
     * Copy constructor for ElectricTruck.
     */
    
    
    public ElectricTruck(ElectricTruck other) {
    	
        super(other.getMake(), other.getModel(), other.getYearOfProduction(), other.getMaxCapacity());
        this.platenumber = other.getPlateNumber(); 
        this.maxAutonomy = other.maxAutonomy;
    }

    /* Getter and setter for maxAutonomy */
    
    /* Gets the maximum autonomy of the truck 
     * which is in kilometers.
     */ 
    
    
    public double getMaxAutonomy() {
    	
    	return maxAutonomy; 
    	
    	}

    public void setMaxAutonomy (double maxAutonomy) {
    	
        if (maxAutonomy < 0) {
        	
            throw new IllegalArgumentException("Autonomy cannot be negative.");
        }
        
        this.maxAutonomy = maxAutonomy;
    }

    @Override
    public String toString() {
    	
        return super.toString() + ", Max Autonomy: " + maxAutonomy + " km";
    }
}
