//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

package vehicle;

/* will create a counter specially for electric car which
 * will start from initials "EC" which represents electric car.
 * 
 * to make it more readable and clear to understand 
 * we will start the EC counter from "1101"
 */

public class ElectricCar extends Car {
	
    private static int ecCounter = 1101; 
    private double maxAutonomy;

    /* Parameterized Constructor */
    
    public ElectricCar(String make, String model, int yearOfProduction, int maxPassengers, double maxAutonomy) {
    	
        super(make, model, yearOfProduction, maxPassengers);
        this.platenumber = "EC" + ecCounter++; 
        this.maxAutonomy = maxAutonomy;
        
        /* We will increment the EC counter after each assigned 
         * EC car, so it will be unique for each EC car.
         */

    }

    /* Getters and Setters */
    
    
    public double getMaxAutonomy() { 
    	
    	return maxAutonomy; 
    	
    }

    public void setMaxAutonomy(double maxAutonomy) {
    	
        if (maxAutonomy < 0) {
        	
            throw new IllegalArgumentException("Autonomy cannot be negative.");
        }
        
        this.maxAutonomy = maxAutonomy;
    }

    /* toString Method */
    
    @Override
    public String toString() {
    	
    	
        return super.toString() + ", Max Autonomy: " + maxAutonomy + " km";
        
    }
}
