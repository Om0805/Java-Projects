//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

package vehicle;

/* This is where we start our code.*/
/* First of all we will create a main class for "vehicle" which will hold
 * commonly used attributes such as : Number plates,maker, model name,
 * year of production.
 * we will treat this class as our base for any vehicles we may create 
 * now or in future at any given point of time.
 */

public class Vehicle {
    protected String platenumber;
    protected String make;
    protected String model;
    protected int yearofproduction;

    /* Default constructor usually used to initialize 
     * the details for the vehicle
     * */
    
    public Vehicle() {
        this.platenumber = "unknown";
        this.make = "unknown";
        this.model = "unknown";
        this.yearofproduction = 0;
    }

    /* Parameterized constructors are used to initialize specific details 
     * about the the vehicle.
     */
    
    public Vehicle(String make, String model, int yearOfProduction) {
        this.make = make;
        this.model = model;
        this.yearofproduction = yearOfProduction;
        this.platenumber = "unassigned"; 
    }

    /* Copy Constructor*/
    
    public Vehicle(Vehicle other) {
        this.platenumber = other.platenumber;
        this.make = other.make;
        this.model = other.model;
        this.yearofproduction = other.yearofproduction;
    }

    /* Getters and Setters methods */
    
    
    public String getPlateNumber() { 
    	
    	return platenumber; 
    	}
    
    public void setPlateNumber(String plateNumber) {
    	
    	this.platenumber = plateNumber; 
    	}

    public String getMake() {
    	
    	return make; 
    	}
    
    public void setMake(String make) { 
    	
    	this.make = make; 
    	}

    public String getModel() {
    	
    	return model; 
    	}
    public void setModel(String model) {
    	
    	this.model = model; 
    	}

    public int getYearOfProduction() { 
    	
    	return yearofproduction; 
    	
    	}
    
    
    public void setYearOfProduction (int yearOfProduction) {
    	
        if (yearOfProduction < 1886) { 
        	
            throw new IllegalArgumentException("Year of production cannot be before 1886.");
        }
        
        this.yearofproduction = yearOfProduction;
    }

    /* toString method does the job of
     * returning a string which will contain the
     * vehicle informatons.
     */
    @Override
    public String toString() {
    	
        return "Vehicle ( Plate Number: " + platenumber + ", Make: " + make + ", Model: " + model + ", Year: " + yearofproduction + ")";
    }

    /* equals Method will just compare two attributes with
     * each other.
     */
    
    
    @Override
    public boolean equals(Object obj) {
    	
        if (this == obj) return true;
        
        if (obj == null || getClass() != obj.getClass()) return false;
        Vehicle other = (Vehicle) obj;
        
        return platenumber.equals(other.platenumber) &&
               make.equals(other.make) &&
               model.equals(other.model) &&
               yearofproduction == other.yearofproduction;
    }
}
