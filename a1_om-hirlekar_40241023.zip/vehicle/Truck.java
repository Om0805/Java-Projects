//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

package vehicle;

/**
 * Abstract class represents a general Truck with a maximum Load capacity.
 * again this will be served as a base class for Electrictruck and disel truck.
 * 
 * Overall, the main motto of this class is to ensure max capacity of the trucks
 * is dealt correctly by the logic.
 */

public abstract class Truck extends Vehicle {
	
    protected double maxcapacity;

    public Truck(String make, String model, int yearofproduction, double maxCapacity) {
    	
        super(make, model, yearofproduction);
        this.maxcapacity = maxCapacity;
    }

    public double getMaxCapacity() {
    	
    	return maxcapacity; 
    	}
    
    public void setMaxCapacity(double maxCapacity) {
    	
    	this.maxcapacity = maxCapacity; 
    	
    	}

    @Override
    
    public String toString() {
    	
        return super.toString() + ", Max Capacity: " + maxcapacity + " kg";
    }

    @Override
    public boolean equals(Object obj) {
    	
        if (!super.equals(obj)) return false;
        Truck other = (Truck) obj;
        
        return maxcapacity == other.maxcapacity;
    }
}
