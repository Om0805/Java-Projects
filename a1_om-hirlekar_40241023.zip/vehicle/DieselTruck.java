//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

package vehicle;


/*
 * Represents an diesel truck with a maximum load capacity and autonomy (range).
 * it also Inherits common truck attributes from the Truck class.
 */

/* will create a counter specially for diesel truck which
* will start from initials "DT" which represents diesel truck.
* 
* to make it more readable and clear to understand 
* we will start the EC counter from "1101"
*/

public class DieselTruck extends Truck {
    private static int dtCounter = 1101; 
    private double fuelTankCapacity;

    /*  Parameterized Constructor */
    
    
    public DieselTruck(String make, String model, int yearOfProduction, double maxCapacity, double fuelTankCapacity) {
    	
        super(make, model, yearOfProduction, maxCapacity);
        this.platenumber = "DT" + dtCounter++; 
        /* We will increment the DT counter after each assigned 
         * DT Truck, so it will be unique for each DT Truck.
         */
        this.fuelTankCapacity = fuelTankCapacity;
    }

    // Getters and Setters
    public double getFuelTankCapacity() {
    	
    	return fuelTankCapacity; 
    	
    }
    /* Returns tank capacity
     * 
     */

    public void setFuelTankCapacity(double fuelTankCapacity) {
    	
        if (fuelTankCapacity < 0) {
        	
            throw new IllegalArgumentException("Fuel tank capacity cannot be negative.");
        }
        
        this.fuelTankCapacity = fuelTankCapacity;
    }

    /* toString Method */
    
    
    @Override
    public String toString() {
    	
        return super.toString() + ", Fuel Tank Capacity: " + fuelTankCapacity + " L";
    }
}
