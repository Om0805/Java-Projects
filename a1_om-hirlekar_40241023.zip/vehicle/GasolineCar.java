//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

package vehicle;

public class GasolineCar extends Car {
	
	/* will create a counter specially for gasoline car which
	 * will start from initials "GC" which represents gasoline car.
	 * 
	 * to make it more readable and clear to understand 
	 * we will start the gc counter from "1101"
	 */
	
    private static int gcCounter = 1101; 

    /* parameter constructors */
    
    
    public GasolineCar(String make, String model, int yearOfProduction, int maxPassengers) {
    	
        super(make, model, yearOfProduction, maxPassengers);
        this.platenumber = "GC" + gcCounter++; 
        
        /* We will increment the GC counter after each assigned 
         * gc car, so it will be unique for each GC car.
         */
    }

    /* toString Method */
    
    
    @Override
    
    public String toString() {
    	
        return super.toString();
    }
}
