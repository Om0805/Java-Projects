//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

package vehicle;

/**
 * Abstract class represents a general car with a maximum passenger capacity.
 * again this will be served as a base class for gasolinecar and electricar.
 * 
 * Overall, the main motto of this class is to ensure maxpassenger
 * is dealt correctly by the logic.
 */


public abstract class Car extends Vehicle {
    protected int maxPassengers;

    /* Parameterized Constructors */
    
    
    public Car(String make, String model, int yearOfProduction, int maxPassengers) {
        super(make, model, yearOfProduction);
        this.maxPassengers = maxPassengers;
    }

    /* Getters and Setters */
    
    
    public int getMaxPassengers() { 
    	
    	return maxPassengers; 
    	
    }

    public void setMaxPassengers(int maxPassengers) { 
    	
        if (maxPassengers < 1) {
        	
            throw new IllegalArgumentException("A car must have at least one passenger seat.");
        }
        
        this.maxPassengers = maxPassengers; 
    }

    /* toString Method */
    
    @Override
    public String toString() {
    	
        return super.toString() + ", Max Passengers: " + maxPassengers;
    }

    /* equals Method */
    
    @Override
    public boolean equals(Object obj) {
    	
        if (this == obj) return true;
        if (!(obj instanceof Car)) return false;
        
        if (!super.equals(obj)) return false;
        
        Car other = (Car) obj;
        return maxPassengers == other.maxPassengers;
    }
}
