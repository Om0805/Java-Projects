//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

package client;


/*
 * Represents a client who rents vehicles from royalrentals.
 * Each client has a unique client Id, name, and contact information.
 */

public class Client {
    private static int clientCounter = 0001; 

    private String clientId;
    private String name;
    private String contactInfo;

    // Default Constructor
    public Client() {
    	
        this.clientId = "c" + clientCounter++;
        this.name = "unknown";
        this.contactInfo = "unknown";
    }

    /*
     * Parameterized constructor for Clients
     * it will also generates a unique client id automatically
     * name the client 
     * and will also handle client infoormations
     */
    
    public Client(String name, String contactInfo) {
    	
        this.clientId = "c" + clientCounter++;
        setName(name);
        setContactInfo(contactInfo);
    }

    /* Copy constructors*
     * 
     * 
     */
    
    public Client(Client other) {
    	
        this.clientId = "c" + clientCounter++; 
        this.name = other.name;
        this.contactInfo = other.contactInfo;
    }


    /* Getters and Setters */
    
    
    public String getClientId() { 
    	
    	return clientId; 
    	
    }
    
    public String getName() {
    	
    	return name; 
    	
    }
    public void setName(String name) {
    	
    	
        if (name == null || name.trim().isEmpty()) {
        	
            throw new IllegalArgumentException("Client name cannot be empty.");
        }
        
        this.name = name;
    }

    public String getContactInfo() { return contactInfo; }
    public void setContactInfo(String contactInfo) {
    	
        if (contactInfo == null || contactInfo.trim().isEmpty()) {
        	
        	
            throw new IllegalArgumentException("Contact info cannot be empty.");
        }
        
        this.contactInfo = contactInfo;
    }

    /* toString Method */
    
    
    @Override
    public String toString() {
    	
        return "Client (ID: " + clientId + ", Name: " + name + ", Contact: " + contactInfo + ")";
    }

    /* equals Method */
    
    
    @Override
    public boolean equals(Object obj) {
    	
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Client other = (Client) obj;
        return clientId.equals(other.clientId) && name.equals(other.name) && contactInfo.equals(other.contactInfo);
    }
}
