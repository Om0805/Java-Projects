//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

package driver;

import vehicle.*;
import client.*;

import java.util.*;


/*
 * we finally reached the main class for RoyalRental.
 * This program will allow employees to manage vehicles, clients.
 */

public class Main {
	
    private static final Scanner scanner = new Scanner(System.in);
    
 /* Separate lists for user added and predefined data
  * so no confusion will be created while generating list of available vehicles and clients.
  */
    
    private static final List<Vehicle> userVehicles = new ArrayList<>();
    private static final List<Client> userClients = new ArrayList<>();
    private static final List<Vehicle> predefinedVehicles = new ArrayList<>();
    private static final List<Client> predefinedClients = new ArrayList<>();

    
    /*
     * Main method for the program will allow the user to choose between menu driven ui
     * or a predefined scenario for testing.
     */

    public static void main(String[] args) {
    	
    	System.out.println("Welcome to RoyalRental main menu created by" + " " + "Om Hirlekar");
    	System.out.println();
    	
        while (true) {  
        	
            System.out.println("\n ROYAL RENTALS MAIN MENU ");
            
            System.out.println("1. Menu-driven Interface");
            
            System.out.println("2. Predefined Scenario (Testing)");
            
            System.out.println("3. Exit");
            
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt ();
            scanner.nextLine(); 

            switch (choice) {
            
            /* i specifically chose to use arrow notations for the switch
             * statements to reduce the step of adding "break"
             */
            
                case 1 -> menuInterface ();
                
                case 2 -> predefinedScenario ();
                
                case 3 -> {
                	
                    System.out.println ("Exiting Thank you");
                    
                    return;  
                }
                
                default -> System.out.println ("Invalid choice please try again (1-3).");
            }
        }
    }

    /*
     * Displays the menu  it also allow the user to perform operations
     * like vehicle management, client management, and additional operations.
     */
    
    
    private static void menuInterface() {
    	
        while (true) {
        	
            System.out.println("\n MENU DRIVEN UI ");
            
            System.out.println("1. Vehicle Management");
            
            System.out.println("2. Client Management");
            
            System.out.println("3. Additional Operations");
            
            System.out.println("4. Back to Main Menu"); 
            
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            
            scanner.nextLine();

            switch (choice) {
            
                case 1 -> vehicleManagement();
                
                case 2 -> clientManagement();
                
                case 3 -> additionalOperations();
            
                case 4 -> {
                	
                	return; 
                	
                } 
                
                default -> System.out.println("Invalid choice please try again (1-4).");
            }
        }
    }


    /*
    * Manages vehicle related operations such as adding, deleting, updating, and listing vehicles.
    */
    
    
    private static void vehicleManagement() {
    	
        while (true) {
        	
            System.out.println("\n Vehicle Management ");
            
            System.out.println("1. Add a vehicle");
            
            System.out.println("2. Delete a vehicle");
            
            System.out.println("3. Update vehicle information");
            
            System.out.println("4. List vehicles by category");
            
            System.out.println("5. Back to main menu");
            
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
            
                case 1 -> addVehicle();
                
                case 2 -> deleteVehicle();
                
                case 3 -> updateVehicle();
                
                case 4 -> listVehiclesByCategory();
                
                case 5 -> {
                	
                	return; 
                	
                }
                
                default -> System.out.println ("Invalid choice please try again (1-5).");
            }
        }
    }
    
    /*
     * Adds a new vehicle to the system based on the user selection of vehicle type
     */

    private static void addVehicle() {
    	
        System.out.println ("Select vehicle type: 1. Gasoline Car  2. Electric Car  3. Diesel Truck  4. Electric Truck");
        
        int type = scanner.nextInt ();
        scanner.nextLine ();

        System.out.print ("Enter Make: ");
        
        String make = scanner.nextLine ();
        
        System.out.print("Enter Model: ");
        
        String model = scanner.nextLine();
        
        System.out.print(" Enter Year of Production: ");
        
        int year = scanner.nextInt();
        

        Vehicle vehicle = null;
        switch (type) {
            case 1 -> {
            	
                System.out.print("Enter Max Passengers: ");
                
                int maxPassengers = scanner.nextInt();
                vehicle = new GasolineCar(make, model, year, maxPassengers);
            }
            
            case 2 -> {
            	
                System.out.print("Enter Max Passengers: ");
                int maxPassengers = scanner.nextInt();
                System.out.print("Enter Max Autonomy: ");
                double maxAutonomy = scanner.nextDouble();
                vehicle = new ElectricCar(make, model, year, maxPassengers, maxAutonomy);
            }
            
            case 3 -> {
            	
                System.out.print("Enter Max Capacity (kg): ");
                double maxCapacity = scanner.nextDouble();
                System.out.print("Enter Fuel Tank Capacity (L): ");
                double fuelTankCapacity = scanner.nextDouble();
                vehicle = new DieselTruck(make, model, year, maxCapacity, fuelTankCapacity);
            }
            
            case 4 -> {
            	
                System.out.print("Enter Max Capacity (kg): ");
                double maxCapacity = scanner.nextDouble();
                System.out.print("Enter Max Autonomy (km): ");
                double maxAutonomy = scanner.nextDouble();
                vehicle = new ElectricTruck(make, model, year, maxCapacity, maxAutonomy);
            }
            
            default -> {
            	
                System.out.println("Invalid type returning to menu.");
                return;
            }
        }

        userVehicles.add(vehicle);

        
        System.out.println("Vehicle added: " + vehicle);
        
    }
    
    
    /*
     * Deletes a vehicle from the system based on the plate number provided by the user
     * can only be done by number plate
     */

    private static void deleteVehicle() {
    	
        System.out.print("Enter Plate Number of vehicle to delete: ");
        
        String plate = scanner.nextLine();
        
        userVehicles.removeIf(v -> v.getPlateNumber().equals(plate));
        System.out.println("Vehicle removed.");
    }
    
    /*
     * Updates the details of a vehicle.
     */

    private static void updateVehicle() {
    	
        System.out.print("Enter Plate Number of vehicle to update: ");
        
        String plate = scanner.nextLine();
        
        for (Vehicle v : userVehicles) {
        	
            if (v.getPlateNumber().equals(plate)) {
            	
                System.out.print("Enter new Make: ");
                
                v.setMake(scanner.nextLine());
                
                System.out.print("Enter new Model: ");
                
                v.setModel(scanner.nextLine());
                
                System.out.println("Vehicle updated.");
                
                return;
            }
        }
        System.out.println("Vehicle not found.");
    }
    
    /*
     * Lists all vehicles in the system 
     */

    private static void listVehiclesByCategory() {
    	
    	if (userVehicles.isEmpty()) {
    		
    	    System.out.println("No user added vehicles.");
    	} else {
    		
    	    System.out.println("\n User Added Vehicles ");
    	    
    	    for (Vehicle v : userVehicles) {
    	    	
    	        System.out.println(v);
    	    }
    	}
    }


    /* client management */
    
    
    private static void clientManagement() {
    	
        while (true) {
        	
            System.out.println("\n Client Management");
            
            System.out.println("1. Add Client");
            
            System.out.println("2. Delete Client");
            
            System.out.println("3. List All Clients");
            
            System.out.println("4. Back to Main Menu");
            
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
            
                case 1 -> addClient();
                
                case 2 -> deleteClient();
                
                case 3 -> listClients();
                
                case 4 -> { 
                	
                	return; 
                	}
                default -> System.out.println("Invalid choice please try again (1-4).");
            }
        }
    }

    private static void addClient() {
    	
        System.out.print("Enter Client Name: ");
        
        String name = scanner.nextLine();
        
        System.out.print("Enter Contact Info: ");
        
        String contact = scanner.nextLine();
        

        Client newClient = new Client(name, contact);
        
        userClients.add(newClient);
        
        System.out.println("Client added successfully: " + newClient);
    }

    private static void deleteClient() {
    	
        System.out.print("Enter Client ID to delete: ");
        String id = scanner.nextLine();

        boolean removed = userClients.removeIf(client -> client.getClientId().equals(id));

        if (removed) {
        	
            System.out.println("Client removed successfully.");
            
        } else {
        	
            System.out.println("Client not found.");
        }
    }

    private static void listClients() {
    	
        if (userClients.isEmpty()) {
        	
            System.out.println("No clients by the user registered.");
            
        } else {
        	
        	
            System.out.println("\n user registered List of Clients ");
            
            for (Client client : userClients) {
                System.out.println(client);
            }
        }
    }

    /* Additional operations.*/
    
    
    private static void additionalOperations() {
        System.out.println("\n Additional Operations");
        
        System.out.println("1. Find the largest diesel truck");
        
        System.out.println("2. Copy electric trucks array");
        
        System.out.print("Enter your choice: ");
        
        int choice = scanner.nextInt();

        switch (choice) {
            case 1 -> System.out.println("Largest Diesel Truck: " + getLargestTruck());
            
            case 2 -> System.out.println("Copied Electric Trucks: " + Arrays.toString(copyVehicles(getElectricTrucksArray())));
            
            default -> System.out.println("Invalid choice.");
        }
    }

    private static DieselTruck getLargestTruck() {
    	
        return userVehicles.stream()
                .filter(v -> v instanceof DieselTruck)
                .map(v -> (DieselTruck) v)
                .max(Comparator.comparingDouble(DieselTruck::getMaxCapacity))
                .orElse(null);
    }

    private static ElectricTruck[] copyVehicles(ElectricTruck[] trucks) {
    	
        return Arrays.stream(trucks).map(ElectricTruck::new).toArray(ElectricTruck[]::new);
        
    }

    private static ElectricTruck[] getElectricTrucksArray() {
    	
    	
        return userVehicles.stream()
                .filter(v -> v instanceof ElectricTruck)
                .toArray(ElectricTruck[]::new);
    }
    
    
    private static void predefinedScenario() {
    	
        System.out.println("\n Running Predefined Scenario ");

        /* Predefined Vehicles */
        
        
        GasolineCar gc1 = new GasolineCar("Maruti Suzuki", "Alto", 2000, 4);
        
        GasolineCar gc2 = new GasolineCar("Honda", "Civic", 2021, 5);
        
        ElectricCar ec1 = new ElectricCar("Tesla", "Model 4", 2023, 5, 500);
        
        ElectricCar ec2 = new ElectricCar("Tata", "Nano", 2010, 4, 100);
        
        DieselTruck dt1 = new DieselTruck("Ford", "blackhawk", 2019, 3000, 100);
        
        DieselTruck dt2 = new DieselTruck("RAM", "2500", 2021, 4000, 150);
        
        ElectricTruck et1 = new ElectricTruck("Rivian", "R1T", 2024, 5000, 450);
        
        ElectricTruck et2 = new ElectricTruck("Tesla", "Cybertruck", 2024, 6000, 700);
        
        System.out.println("\n Predefined scenario loaded, This data will not appear in user lists.");

        /* Predefined  Clients */
        
        
        Client c1 = new Client("crazy xyz", "123-456-7890");
        
        Client c2 = new Client("unknown user", "987-654-3210");
        
        Client c3 = new Client("hacker me", "111-222-3333");
        

        /* Lists *?
         * 
         */
        
        predefinedVehicles.addAll(List.of(gc1, gc2, ec1, ec2, dt1, dt2, et1, et2));
        predefinedClients.addAll(List.of(c1, c2, c3));

        // Display pre defined vehicles and clients
        
        System.out.println("\n Vehicles ");
        
        predefinedVehicles.forEach(System.out::println);
        
        System.out.println("\n Clients ");
        
        predefinedClients.forEach(System.out::println);

        /* Test equals() method */
        
        
        System.out.println("\n Testing equals() Method ");
        
        System.out.println("Comparing different classes: " + gc1.equals(dt1)); 
        
        System.out.println("Comparing same class, different attributes: " + ec1.equals(ec2)); 
        
        GasolineCar gc3 = new GasolineCar("Toyota", "Camry", 2022, 5);
        
        System.out.println("Comparing identical objects: " + gc1.equals(gc3)); 

        /* Test getLargestTruck */
        
        
        Truck largestTruck = getLargestTruck();
        
        System.out.println("\nLargest Diesel Truck: " + (largestTruck != null ? largestTruck : "None found"));

        /* Test copyvehicles */
        
        ElectricTruck[] copiedTrucks = copyVehicles(getElectricTrucksArray());
        
        System.out.println("\nCopied Electric Trucks: " + Arrays.toString(copiedTrucks));
        

        System.out.println("\n Predefined Scenario Completed ");
        
        System.out.print("Enter 1 to return to the Main Menu: ");
        int choice = scanner.nextInt();
        if (choice == 1) {
            return; 
        }
    }
}
