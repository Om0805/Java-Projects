import java.io.*;
import java.util.*;

public class TradeManager {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // 🌟 Welcome message
        System.out.println("-----------------------------------------------------");
        System.out.println("        Welcome to the Tariff Management System");
        System.out.println("-----------------------------------------------------");
        System.out.println("This system simulates international trade conflicts,");
        System.out.println("tariff evaluations, and lets you test linked list");
        System.out.println("operations and special cases.");
        System.out.println("-----------------------------------------------------\n");

        TariffList mainList = new TariffList();
        TariffList copiedList = null;

        // Load tariffs from file
        try {
            Scanner tariffFile = new Scanner(new File("Tariffs.txt"));
            while (tariffFile.hasNextLine()) {
                String line = tariffFile.nextLine().trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(" ");
                String destination = parts[0];
                String origin = parts[1];
                String category = parts[2];
                double minTariff = Double.parseDouble(parts[3]);

                if (!mainList.contains(origin, destination, category)) {
                    mainList.addToStart(new Tariff(destination, origin, category, minTariff));
                }
            }
            tariffFile.close();
        } catch (Exception e) {
            System.out.println("Error reading Tariffs.txt");
            return;
        }

        // Load trade requests
        ArrayList<String> tradeRequests = new ArrayList<>();
        try {
            Scanner requestFile = new Scanner(new File("TradeRequests.txt"));
            while (requestFile.hasNextLine()) {
                String line = requestFile.nextLine().trim();
                if (!line.isEmpty()) tradeRequests.add(line);
            }
            requestFile.close();
        } catch (Exception e) {
            System.out.println("Error reading TradeRequests.txt");
            return;
        }

        // Evaluate trade requests
        for (String request : tradeRequests) {
            String[] parts = request.split(" ");
            String requestID = parts[0];
            String origin = parts[1];
            String destination = parts[2];
            String category = parts[3];
            double tradeValue = Double.parseDouble(parts[4]);
            double proposedTariff = Double.parseDouble(parts[5]);

            TariffList.TariffNode node = mainList.find(origin, destination, category);
            if (node == null) {
                
                System.out.println(requestID + " - Rejected. \n No tariff policy found.\n");
                continue;
            }

            double minimumTariff = node.getData().getMinimumTariff();
            String result = mainList.evaluateTrade(proposedTariff, minimumTariff);

            if (result.equals("Accepted")) {
                System.out.println(requestID + " - Accepted.");
                System.out.println("Proposed tariff meets or exceeds the minimum requirement.\n");
            } else if (result.equals("Conditionally Accepted")) {
                double surcharge = tradeValue * ((minimumTariff - proposedTariff) / 100);
                System.out.printf("%s - Conditionally Accepted.\n", requestID);
                System.out.printf("Proposed tariff %.2f%% is within 20%% of the required minimum tariff %.2f%%.\n", proposedTariff, minimumTariff);
                System.out.printf("A surcharge of $%.2f is applied.\n\n", surcharge);
            } else {
                System.out.printf("%s - Rejected.\nProposed tariff %.2f%% is more than 20%% below the required minimum tariff %.2f%%.\n\n",
                        requestID, proposedTariff, minimumTariff);
            }
        }

        // Menu
        String choice;
        do {
            System.out.println("\nWhat would you like to do next?");
            System.out.println("1. Search for a tariff");
            System.out.println("2. Test Tariff constructors and methods");
            System.out.println("3. Test special cases on a copy of the list");
            System.out.println("4. Exit");
            System.out.print("Enter your choice (1, 2, 3, 4): ");
            choice = input.next();

            switch (choice) {
                case "1":
                    input.nextLine();
                    System.out.print("Search for a tariff (enter Origin, Destination, Category separated by commas): ");
                    String[] searchParts = input.nextLine().split(",");
                    if (searchParts.length != 3) {
                        System.out.println("Invalid input. Please enter exactly 3 values.");
                        break;
                    }
                    String origin = searchParts[0].trim();
                    String destination = searchParts[1].trim();
                    String category = searchParts[2].trim();
                    TariffList.TariffNode found = mainList.find(origin, destination, category);
                    if (found != null) {
                        System.out.println("Tariff found: " + found.getData());
                    } else {
                        System.out.println("Tariff not found.");
                    }
                    break;

                case "2":
                    input.nextLine();
                    System.out.print("Enter Tariff (destination,origin,category,minimumTariff): ");
                    String[] parts = input.nextLine().split(",");
                    if (parts.length != 4) {
                        System.out.println("Invalid input.");
                        break;
                    }
                    String dest = parts[0].trim();
                    origin = parts[1].trim();
                    category = parts[2].trim();
                    double minTariff = Double.parseDouble(parts[3].trim());

                    Tariff userTariff = new Tariff(dest, origin, category, minTariff);
                    System.out.println("Tariff created: " + userTariff);

                    Tariff copiedTariff = new Tariff(userTariff);
                    System.out.println("Copied Tariff: " + copiedTariff);
                    System.out.println("Are original and copy equal? " + userTariff.equals(copiedTariff));

                    System.out.print("Enter new minimum tariff for the copied object: ");
                    double newTariff = input.nextDouble();
                    copiedTariff.setMinimumTariff(newTariff);
                    System.out.println("Modified Copied Tariff: " + copiedTariff);
                    System.out.println("Are original and modified copy still equal? " + userTariff.equals(copiedTariff));

                    Tariff clonedTariff = userTariff.clone();
                    System.out.println("Cloned Tariff: " + clonedTariff);
                    System.out.println("Is the cloned tariff equal to original? " + userTariff.equals(clonedTariff));

                    copiedList = new TariffList(mainList); 
                    break;

                case "3":
                  
                    String subChoice;
                    do {
                        System.out.println("\n--- Interactive Special Case Testing ---");
                        System.out.println("a. Insert at custom index");
                        System.out.println("b. Delete from custom index");
                        System.out.println("c. Replace at custom index");
                        System.out.println("d. Find a tariff");
                        System.out.println("e. Delete from start");
                        System.out.println("f. Back to main menu");
                        System.out.print("Choice (a-f): ");
                        subChoice = input.next();

                        switch (subChoice) {
                            case "a":
                                input.nextLine();
                                System.out.print("Enter values (destination,origin,category,tariff,index): ");
                                String[] insertParts = input.nextLine().split(",");
                                if (insertParts.length != 5) {
                                    System.out.println("Invalid input, Please enter 5 values.");
                                    break;
                                }
                                try {
                                    String d = insertParts[0].trim();
                                    String o = insertParts[1].trim();
                                    String c = insertParts[2].trim();
                                    double t = Double.parseDouble(insertParts[3].trim());
                                    int idx = Integer.parseInt(insertParts[4].trim());
                                    copiedList.insertAtIndex(new Tariff(d, o, c, t), idx);
                                    System.out.println("Inserted at index " + idx);
                                } catch (Exception e) {
                                    System.out.println("Error: " + e.getMessage());
                                }
                                break;

                            case "b":
                                System.out.print("Enter index to delete from: ");
                                int delIdx = input.nextInt();
                                try {
                                    copiedList.deleteFromIndex(delIdx);
                                    System.out.println("Deleted node at index " + delIdx);
                                } catch (Exception e) {
                                    System.out.println("Error: " + e.getMessage());
                                }
                                break;

                            case "c":
                                input.nextLine();
                                System.out.print("Enter values (destination,origin,category,tariff,index): ");
                                String[] replaceParts = input.nextLine().split(",");
                                if (replaceParts.length != 5) {
                                    System.out.println("Invalid input. Please enter 5 values.");
                                    break;
                                }
                                try {
                                    String d = replaceParts[0].trim();
                                    String o = replaceParts[1].trim();
                                    String c = replaceParts[2].trim();
                                    double t = Double.parseDouble(replaceParts[3].trim());
                                    int idx = Integer.parseInt(replaceParts[4].trim());
                                    copiedList.replaceAtIndex(new Tariff(d, o, c, t), idx);
                                    System.out.println("Attempted replacement at index " + idx);
                                } catch (Exception e) {
                                    System.out.println("Error: " + e.getMessage());
                                }
                                break;

                            case "d":
                                input.nextLine();
                                System.out.print("Enter values (origin,destination,category): ");
                                String[] findParts = input.nextLine().split(",");
                                if (findParts.length != 3) {
                                    System.out.println("Invalid input. Please enter exactly 3 values.");
                                    break;
                                }
                                origin = findParts[0].trim();
                                destination = findParts[1].trim();
                                category = findParts[2].trim();
                                TariffList.TariffNode foundNode = copiedList.find(origin, destination, category);
                                if (foundNode != null) {
                                    System.out.println("Tariff found: " + foundNode.getData());
                                } else {
                                    System.out.println("Tariff not found.");
                                }
                                break;

                            case "e":
                                copiedList.deleteFromStart();
                                System.out.println("Deleted node from start.");
                                break;

                            case "f":
                                System.out.println("Returning to main menu...");
                                break;

                            default:
                                System.out.println("Invalid choice.");
                        }
                    } while (!subChoice.equals("f"));
                    break;

                case "4":
                    // 👋 Exit message
                    System.out.println("\n-----------------------------------------------------");
                    System.out.println("Thank you for using the Tariff Management System.");
                    System.out.println("Goodbye");
                    System.out.println("-----------------------------------------------------");
                    break;

                default:
                    System.out.println("Invalid choice. Please enter 1, 2, 3, or 4.");
            }

        } while (!choice.equals("4"));
        
        input.close();
    }
}
