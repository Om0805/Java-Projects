//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

// This class represents a tariff rule determined by the destination countries.
public class Tariff {
    private String destinationCountry;
    private String originCountry;
    private String productCategory;
    private double minimumTariff;

    // Constructor 
    public Tariff(String destinationCountry, String originCountry, String productCategory, double minimumTariff) {
        this.destinationCountry = destinationCountry;
        this.originCountry = originCountry;
        this.productCategory = productCategory;
        this.minimumTariff = minimumTariff;
    }

    // Copy constructor for deep copy 
    public Tariff(Tariff other) {
        this.destinationCountry = other.destinationCountry;
        this.originCountry = other.originCountry;
        this.productCategory = other.productCategory;
        this.minimumTariff = other.minimumTariff;
    }

    // clone Copy 
    public Tariff clone() {
        return new Tariff(this);
    }

    // Checkking if two tariff objects are equal or no.
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Tariff)) return false;
        Tariff other = (Tariff) obj;
        return destinationCountry.equals(other.destinationCountry) &&
               originCountry.equals(other.originCountry) &&
               productCategory.equals(other.productCategory) &&
               minimumTariff == other.minimumTariff;
    }

    // Tostring method
    public String toString() {
        return destinationCountry + " " + originCountry + " " + productCategory + " " + minimumTariff;
    }

    // Accessor method
    public String getDestinationCountry() { return destinationCountry; }
    public String getOriginCountry() { return originCountry; }
    public String getProductCategory() { return productCategory; }
    public double getMinimumTariff() { return minimumTariff; }

    // setter.
    public void setMinimumTariff(double minimumTariff) { this.minimumTariff = minimumTariff; }
}