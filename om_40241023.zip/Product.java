//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

import java.util.ArrayList;
import java.util.Scanner; 

/* This class represents all the available products information, 
including their name, country, category, and price. */


public class Product {
	// name, country, category, initial price, & final price.
	
	String productName;
	String country;
	String category;
	double initialPrice;
	double finalPrice;
	
	
	// Constructor initializes the products
	public Product(String productName, String country, String category, double initialPrice) {
		
		this.productName = productName;
		this.country = country;
		this.category = category;
		this.initialPrice = initialPrice;
		this.finalPrice = finalPrice;
		
	}
	
	 // Applies a tariff rate
	void applyTariff(double rate) {
		
		finalPrice = initialPrice + (initialPrice * rate / 100);
		
	}
	
	public String toFileFormat() {
		return productName + "," + country + "," + category + "," + finalPrice;
	}
	
	// Let's create the logic for the tariffs for the specific countries.
	
	public static double getTariffRate(String country, String category) {
		
		switch (country) {
		
		case "China": return 25;
		case "USA": return category.equals("Electronics") ? 10 : 0;
		case "Japan": return category.equals("Automobile") ? 15 : 0;
		case "India": return category.equals("Agriculture") ? 5 : 0;
        case "South Korea": return category.equals("Electronics") ? 8 : 0;
        case "Saudi Arabia": return category.equals("Energy") ? 12 : 0;
        case "Germany": return category.equals("Manufacturing") ? 6 : 0;
        case "Bangladesh": return category.equals("Textile") ? 4 : 0;
        case "Brazil": return category.equals("Agriculture") ? 9 : 0;

		default: return 0;
		}
	}
	

}
