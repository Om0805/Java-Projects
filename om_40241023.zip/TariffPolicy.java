//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

public interface TariffPolicy {
	// This interface defines  policy for evaluating a trade request.
	
	 String evaluateTrade(double proposedTariff, double minimumTariff);
}
