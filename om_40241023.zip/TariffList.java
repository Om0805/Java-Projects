//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

// This class represents a linked list of tariff objects and manages all node operations.

import java.util.NoSuchElementException;

public class TariffList implements TariffPolicy {

    // Inner class representing a node in the linked list
    class TariffNode {
        private Tariff data;
        private TariffNode next;

        // Default constructor
        public TariffNode() {
            data = null;
            next = null;
        }

        // Parameterized constructor
        public TariffNode(Tariff data, TariffNode next) {
            this.data = new Tariff(data);
            this.next = next;
        }

        // Copy constructor
        public TariffNode(TariffNode node) {
            this.data = new Tariff(node.data);
            this.next = (node.next != null) ? new TariffNode(node.next) : null;
        }

        // Clone method
        public TariffNode clone() {
            return new TariffNode(this);
        }

        // Equals method
        public boolean equals(TariffNode other) {
            return this.data.equals(other.data);
        }

        // Getters and setters
        public Tariff getData() { return data; }
        public void setData(Tariff data) { this.data = data; }
        public TariffNode getNext() { return next; }
        public void setNext(TariffNode next) { this.next = next; }
    }

    private TariffNode head;
    private int size;

    // Getter for head
    public TariffNode getHead() {
        return head;
    }

    // Returns the size of the list
    public int size() {
        return size;
    }

    // Default constructor
    public TariffList() {
        head = null;
        size = 0;
    }

    // Copy constructor
    public TariffList(TariffList other) {
        if (other.head == null) {
            head = null;
            size = 0;
        } else {
            head = new TariffNode(other.head);
            TariffNode current = head;
            TariffNode otherCurrent = other.head.getNext();

            while (otherCurrent != null) {
                current.setNext(new TariffNode(otherCurrent));
                current = current.getNext();
                otherCurrent = otherCurrent.getNext();
            }
            size = other.size;
        }
    }

    // Adds a Tariff to the start of the list
    public void addToStart(Tariff tariff) {
        head = new TariffNode(tariff, head);
        size++;
    }

    // Inserts a Tariff]
    public void insertAtIndex(Tariff tariff, int index) {
        if (index < 0 || index > size) throw new NoSuchElementException("Invalid index");
        if (index == 0) {
            addToStart(tariff);
            return;
        }
        TariffNode prev = head;
        for (int i = 0; i < index - 1; i++) prev = prev.getNext();
        prev.setNext(new TariffNode(tariff, prev.getNext()));
        size++;
    }

    // Deletes a Tariff
    public void deleteFromIndex(int index) {
        if (index < 0 || index >= size) throw new NoSuchElementException("Invalid index");
        if (index == 0) {
            deleteFromStart();
            return;
        }
        TariffNode prev = head;
        for (int i = 0; i < index - 1; i++) prev = prev.getNext();
        prev.setNext(prev.getNext().getNext());
        size--;
    }

    // Deletes the first Tariff in the list
    public void deleteFromStart() {
        if (head != null) {
            head = head.getNext();
            size--;
        }
    }

    // Replaces the Tariff at the specified index
    public void replaceAtIndex(Tariff tariff, int index) {
        if (index < 0 || index >= size) return;
        TariffNode current = head;
        for (int i = 0; i < index; i++) current = current.getNext();
        current.setData(new Tariff(tariff));
    }

    // Finds a Tariff by origin, destination, and category and prints iterations
    public TariffNode find(String origin, String destination, String category) {
        TariffNode current = head;

        while (current != null) {
            Tariff t = current.getData();
            if (t.getOriginCountry().equals(origin) &&
                t.getDestinationCountry().equals(destination) &&
                t.getProductCategory().equals(category)) {
                
                return current;
            }
            current = current.getNext();
        }

        
        return null;
    }

    
    public boolean contains(String origin, String destination, String category) {
        return find(origin, destination, category) != null;
    }

    // Compares this list with another
    public boolean equals(TariffList other) {
        if (this.size != other.size) return false;
        TariffNode current1 = this.head;
        TariffNode current2 = other.head;
        while (current1 != null && current2 != null) {
            if (!current1.getData().equals(current2.getData())) return false;
            current1 = current1.getNext();
            current2 = current2.getNext();
        }
        return true;
    }

    // Evaluates a trade request
    public String evaluateTrade(double proposedTariff, double minimumTariff) {
        if (proposedTariff >= minimumTariff)
            return "Accepted";
        else if (proposedTariff >= 0.8 * minimumTariff)
            return "Conditionally Accepted";
        else
            return "Rejected";
    }
}
