//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

import java.io.*;
import java.util.*;

public class TariffManager {
    public static void main(String[] args) {
        ArrayList<Product> products = new ArrayList<>();

        try {
            Scanner scanner = new Scanner(new File("TradeData.txt"));

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(",");
                String name = parts[0];
                String country = parts[1];
                String category = parts[2];
                double price = Double.parseDouble(parts[3]);

                Product p = new Product(name, country, category, price);
                double rate = Product.getTariffRate(country, category);  // Uses your logic
                p.applyTariff(rate);
                products.add(p);
            }
            scanner.close();

            // Sort alphabetically by product name
            products.sort(Comparator.comparing(prod -> prod.productName));

            PrintWriter writer = new PrintWriter("UpdatedTradeData.txt");
            for (Product p : products) {
                writer.println(p.toFileFormat());
            }
            writer.close();

            System.out.println("UpdatedTradeData.txt created successfully.");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
