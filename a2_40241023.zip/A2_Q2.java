//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 248 Section H - Fall 2024
//----------------------------------------------

import java.util.Scanner;
public class A2_Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		
		// Welcome Statement
		
		System.out.println("****************************************************************************************");
		System.out.println("                          Montreal Currency Exchange Shop!                              ");
		System.out.println("****************************************************************************************");
		System.out.println();
		
		//Ask user for inputs.
		System.out.println("Welcome to the Montreal Currency Exchange Shop!");
		System.out.print("Do you want to buy foreign currency (B) or sell foreign currency (S)? ");
		String type1 = scan.next().toUpperCase();
		
		// Currency details
		String currency = "";
		double amount, output = 0;
		double rate = 0.0;
		
		//currency conversion rates
		double buyUSD = 1.30, sellUSD = 1.25;
		double buyEUR = 1.55, sellEUR = 1.50;
		double buyGBP = 1.80, sellGBP = 1.75;
		double buyJPY = 0.012, sellJPY = 0.01;
		double buyAUD = 1.00, sellAUD = 0.95;
		
		
		// if-else statements
		if (type1.equals("B")) {
			System.out.print("Enter the currency you want to buy (USD, EUR, GBP, JPY, AUD): ");
			currency = scan.next().toUpperCase();
            System.out.print("Enter the amount of " + currency + " you want to buy: ");
            amount = scan.nextDouble();
            
        // switch statements to buy currency   
            switch (currency) {
            case "USD":
            	rate = sellUSD;
            	break;
            case "EUR":
            	rate = sellEUR;
            	break;
            case "GBP":
            	rate = sellGBP;
            	break;
            case "JPY":
            	rate = sellJPY;
            	break;
            case "AUD":
            	rate = sellAUD;
            	break;
            
            }
            
            
            output = amount * rate;
            System.out.println("You need to spend " + output + " CAD to receive " + amount + " " + currency);
            System.out.println("Thank you for visiting!");
            
		} else if (type1.equals("S")) {
			System.out.print("Enter the CAD amount you would like to receive: ");
			amount = scan.nextDouble();
            System.out.print("Enter the target currency to sell (USD, EUR, GBP, JPY, AUD): ");
            currency = scan.next().toUpperCase();
            
        // Switch statements to sell currency
            
            switch (currency) {
            case "USD":
            	rate = buyUSD;
            	break;
            case "EUR":
            	rate = buyEUR;
            	break;
            case "GBP":
            	rate = buyGBP;
            	break;
            case "JPY":
            	rate = buyJPY;
            	break;
            case "AUD":
            	rate = buyAUD;
            	break;
            
            }
            
            output = amount / rate;
            System.out.println("You will need to spend " + output + " " + currency + " to receive " + amount + " " + "CAD");
            System.out.println("Thank you for visiting!");
       }
		
		// closing the scanner.
		scan.close();

	}
}
