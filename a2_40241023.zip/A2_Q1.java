//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 248 Section H - Fall 2024
//----------------------------------------------

import java.util.Scanner;
public class A2_Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		
		//Welcome statement
		
		System.out.println("###########################################################################");
		System.out.println("                      Fall Adventure Planner!!!                            ");
		System.out.println("###########################################################################");
		System.out.println();
		System.out.println("Welcome to the Fall Adventure Planner");
		
		// ask user for inputs
		
		System.out.print("Enter the current temperature" + " " + "(*C): ");
		int temperature = scan.nextInt();
		
		System.out.print("Enter the weather conditions" + " " + "(sunny/rainy/snowy): ");
		String weather = scan.next();
		
		String weather1 = weather.toLowerCase();
		System.out.println();
		
		// if - else statements
		
		if (weather1.equals("rainy")) {
			
            System.out.println("Recommended clothing: Waterproof clothing.");
            System.out.println("Safety tip: Be cautious of slippery paths!");
        } else if (weather1.equals("snowy")) {

            System.out.println("Recommended clothing: Heavy winter clothing.");
            System.out.println("Safety tip: Stay warm and watch out for icy conditions!");
        } else if (weather1.equals("sunny")) {

            if (temperature > 20) {
                System.out.println("Recommended clothing: Light clothing (t-shirt and shorts).");
                
            } else if (temperature >= 10 && temperature <= 20) {
                System.out.println("Recommended clothing: A light jacket.");
                
            } else if (temperature < 10) {
                System.out.println("Recommended clothing: Warm clothing (sweater and a coat).");
                
            }
            System.out.println("Safety tip: Don't forget sunscreen and stay hydrated!");
        }
		
		
		
		// closing statement.
		System.out.println("Thank you for using the Fall Adventure Planner!");
		
		scan.close();
	}

}
