//----------------------------------------------
//Assignment 0
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------
public class Book {
	
	private String title;
	private String author;
	private long ISBN;
	private double price;
	
	private static int numberofbooks = 0;
	
	public Book(String title, String author, long ISBN, double price) {
		this.title = title;
		this.author = author;
		this.ISBN = ISBN;
		this.price= price;
		numberofbooks++;
		
	}

	public String gettitle() {
		return title;
	}
	
	public void settitle(String title) {
		this.title = title;
	}
	
	public String getauthor() {
		return author;
	}
	
	public void setauthor(String author) {
		this.author = author;
	}
	
	public long getISBN() {
		return ISBN;
	}
	
	public void setISBN (long ISBN) {
		this.ISBN = ISBN;
	}
	
	public double getprice() {
        return price;
    }

    public void setprice(double price) {
        this.price = price;
    }
    
    public static int findnumberofcreatedbooks() {
    	return numberofbooks;
    }
    
    @Override
    public boolean equals(Object obj) {
    	if(this == obj) return true;
    	if (obj == null || getClass() != obj.getClass()) return false;
    	Book book = (Book) obj;
    	return ISBN == book.ISBN && Double.compare(book.price, price) ==0;
    }
    
    @Override
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", ISBN: " + ISBN + ", Price: $" + price;
    }
}
