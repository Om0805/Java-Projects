//----------------------------------------------
//Assignment 0
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

import java.util.Scanner;
public class BookStoreManager {
	
	public static final String password = "249";
	public static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		System.out.println("Welcome to the Bookstore Management System!");

        System.out.print("Enter the maximum number of books your bookstore can contain: ");
        
        int maxBooks = scan.nextInt();
        Book[] inventory = new Book[maxBooks];
        
        int failedAttempts = 0;
        
        while (true) {
            displayMainMenu();
            
            int choice = scan.nextInt();
            scan.nextLine();
            
            switch (choice) {
                case 1:
                    if (!authenticateOwner()) {
                        failedAttempts++;
                        
                        if (failedAttempts == 12) {
                            System.out.println("Program detected suspicious activities and will terminate immediately!");
                            return;
                        }
                        
                        continue;
                    }
                    
                    addBooks(inventory);
                    break;
                    
                case 2:
                    updateBook(inventory);
                    break;
                    
                case 3:
                    searchByAuthor(inventory);
                    break;
                    
                case 4:
                    filterByPrice(inventory);
                    break;
                    
                case 5:
                    System.out.println("Thank you for using the Bookstore Manager. Goodbye!");
                    return;
                    
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                }
        	 }
          }
	
	
	private static void displayMainMenu() {
        System.out.println("\nMain Menu:");
        System.out.println("1. Enter new books(password required)");
        System.out.println("2. Change in information of a book(password required)");
        System.out.println("3. Display all books by a specific Author");
        System.out.println("4. Display all books under a certain price");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
    }
	
	private static boolean authenticateOwner() {
        for (int i = 0; i < 3; i++) {
            System.out.print("Enter password: ");
            String inputPassword = scan.nextLine();
            
            if (inputPassword.equals(password)) {
                return true;
            }
            
            System.out.println("Incorrect password. Try again.");
        }
        
        System.out.println("Program detected suspicious activities and will terminate immediately!");
        return false;
    }
	
	private static void addBooks(Book[] inventory) {
        System.out.print("Enter number of books to add: ");
        int numBooks = scan.nextInt();
        scan.nextLine();
        
        int count = 0;
        for (int i = 0; i < inventory.length; i++) {
            if (inventory[i] == null && count < numBooks) {
            	
                System.out.print("Enter book title: ");
                
                String title = scan.nextLine();
                
                System.out.print("Enter author: ");
                
                String author = scan.nextLine();
                
                System.out.print("Enter ISBN: ");
                
                long ISBN = scan.nextLong();
                
                System.out.print("Enter price: ");
                
                double price = scan.nextDouble();
                
                scan.nextLine();
                
                inventory[i] = new Book(title, author, ISBN, price);
                count++;
            }
        }
        
        if (count < numBooks) {
            System.out.println("Not enough space in inventory. Only " + count + " books added.");
        }
    }

	
	private static void updateBook(Book[] inventory) {
        System.out.print("Enter book index to update: ");
        int index = scan.nextInt();
        scan.nextLine();
        
        if (index < 0 || index >= inventory.length || inventory[index] == null) {
            System.out.println("Invalid index or no book exists at this index.");
            return;
        }

        Book book = inventory[index];
        System.out.println("Current book details: " + book);
        System.out.println("1. Update title\n2. Update author\n3. Update ISBN\n4. Update price\n5. Exit update");
        
        while (true) {
            System.out.print("Enter choice: ");
            int choice = scan.nextInt();
            scan.nextLine();
            if (choice == 5) break;
            switch (choice) {
            
                case 1: 
                	System.out.print("New title: "); 
                	book.settitle(scan.nextLine()); 
                	break;
                	
                case 2: 
                	System.out.print("New author: "); 
                	book.setauthor(scan.nextLine()); 
                	break;
                	
                case 3: 
                	System.out.print("New ISBN: "); 
                	book.setISBN(scan.nextLong()); 
                	scan.nextLine(); 
                	break;
                	
                case 4: 
                	System.out.print("New price: "); 
                	book.setprice(scan.nextDouble()); 
                	scan.nextLine(); 
                	break;
                	
                default: 
                	System.out.println("Invalid choice.");
            }
            System.out.println("Updated book details: " + book);
        }
    }

    private static void searchByAuthor(Book[] inventory) {
        System.out.print("Enter author name: ");
        String author = scan.nextLine();
        for (Book book : inventory) {
            if (book != null && book.getauthor().equalsIgnoreCase(author)) {
                System.out.println(book);
            }
        }
    }

    private static void filterByPrice(Book[] inventory) {
        System.out.print("Enter max price: ");
        double maxPrice = scan.nextDouble();
        for (Book book : inventory) {
            if (book != null && book.getprice() < maxPrice) {
                System.out.println(book);
            }
        }
    }

}
