// quebec's provincial tax based on salaries of employees.
public class ProvincialIncomeTax extends Deductions {
	
	public ProvincialIncomeTax (double grossSalary) {
		
		super (grossSalary);
	}
	
	@Override
	public double calculateTax() {
		 if (grossSalary <= 18571) return 0;
	        else if (grossSalary <= 53255) return (grossSalary - 18571) * 0.14;
	        else if (grossSalary <= 106495) return (53255 - 18571) * 0.14 + (grossSalary - 53255) * 0.19;
	        else if (grossSalary <= 129590) return (53255 - 18571) * 0.14 + (106495 - 53255) * 0.19 + (grossSalary - 106495) * 0.24;
	        else return (53255 - 18571) * 0.14 + (106495 - 53255) * 0.19 + (129590 - 106495) * 0.24 + (grossSalary - 129590) * 0.2575;
	}

}
