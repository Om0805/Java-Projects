//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

// Abstract  class for all tax deductions
public abstract class Deductions {
	
	protected double grossSalary;
	
	//constructor
	public Deductions (double grossSalary) {
		
		this.grossSalary = grossSalary;
		
	}
	// another abstract method to calculate tax.
	public abstract double calculateTax();

}
