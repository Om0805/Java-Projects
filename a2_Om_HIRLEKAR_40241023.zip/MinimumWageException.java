//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

//  exception for employees earning below minimum wage (15.75)
public class MinimumWageException extends Exception {
	
	public MinimumWageException(double wage) {
		super ("Error: Hourly wage $" + wage + " is below the minimum of $15.75.");
	}
}
