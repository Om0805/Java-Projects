//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

// QPIP quebec parental insurance plan..
public class QPIP extends Deductions{
	
	public QPIP (double grossSalary) {
		
		super(grossSalary);
		
	}
	
	@Override
	
	public double calculateTax() {
		
		// 0.494% of gross salary
		double deductions = grossSalary * 0.00494;
		return Math.min(deductions,  484.12);
	}

}
