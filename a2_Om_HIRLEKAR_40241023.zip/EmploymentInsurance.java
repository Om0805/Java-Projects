//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

// Employment Insurance EI
public class EmploymentInsurance extends Deductions{

	public EmploymentInsurance(double grossSalary) {
		super(grossSalary);
	}
	
	@Override
	public double calculateTax() {
		
		// 1.64% of gross salary
		double deduction = grossSalary * 0.0164;
		return Math.min(deduction,  1077.48);
	}
	
}
