//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

// QPP  quebec pension plan deductions.

public class QPP extends Deductions{
	
	public QPP (double grossSalary) {
		
		super(grossSalary);
		
	}
	
	@Override
	public double calculateTax() {
		
		// 10.8% of gross salary.
		double deduction = grossSalary* 0.108;
		return Math.min(deduction,  7700.40);
	}

}
