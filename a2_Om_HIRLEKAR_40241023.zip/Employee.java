//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------
public class Employee {
	
	// employee Data
	
	private String employeeNumber;
	private String firstName;
	private String lastName;
	private double hoursWorked;
	private double hourlyWages;
	private double grossSalary;
	
	// constructor
	
	public Employee(String employeeNumber, String firstName, String lastName, double hoursWorked, double hourlyWage) 
            throws MinimumWageException {
        
        if (hourlyWage < 15.75) {
            throw new MinimumWageException(hourlyWage); 
        }
		this.employeeNumber = employeeNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.hoursWorked = hoursWorked;
		this.hourlyWages = hourlyWage;
		
		this.grossSalary = calculateGrossSalary();
	}
	
	// calculating salary for 52 weeks (1 year)
	
	private double calculateGrossSalary() {
		return hoursWorked * hourlyWages * 52;
	}
	
	// Getters.
	
	public String getEmployeeNumber() {

		return employeeNumber;
	}
	
	public String getFirstName() {
		
		return firstName;
	}
	
	public String getLastName () {
		
		return lastName;
	}
	
	public double getGrossSalary() {
		
		return grossSalary;
	}
	
	// calculate all the deductions.
	
	public double calculateTotalDeductions() {
		
		return new FederalIncomeTax(grossSalary).calculateTax()
				+ new ProvincialIncomeTax(grossSalary).calculateTax()
				+ new QPP(grossSalary).calculateTax()
	            + new QPIP(grossSalary).calculateTax()
	            + new EmploymentInsurance(grossSalary).calculateTax();
	}
	
	public double calculateNetSalary() {
		return grossSalary - calculateTotalDeductions();
		
	}

}
