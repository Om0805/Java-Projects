//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class PayrollProcessor {
    public static void main(String[] args) {
    	
    	// We created an array to store Employee objects (for now will do max 100 employees.)
    	
        Employee[] employees = new Employee[100];
        int count = 0;
        int errorCount = 0;

        System.out.println("> Opening file payroll...");
        System.out.println();
        
        System.out.println("> Reading file payroll...");
        System.out.println();

        
        //this will write error into our payroolError.txt file.
        PrintWriter errorWriter = null;
        
        // This will write the payroll report.
        PrintWriter reportWriter = null;
        
        // This only reads the txt file (payroll.txt)
        Scanner fileReader = null;

        try {
        	
        	// Opens the input file (payroll.txt)
        	
            File inputFile = new File("payroll.txt");
            fileReader = new Scanner(inputFile);
            errorWriter = new PrintWriter("payrollError.txt");
            reportWriter = new PrintWriter("payrollReport.txt");
            
            
            // Reads each line in the file.
            while (fileReader.hasNextLine()) {
                String line = fileReader.nextLine();
                String[] parts = line.trim().split("\\s+");

                try {
                    if (parts.length != 5) {
                    	
                    	// checks if it is only 5 components or no.
                        throw new IllegalArgumentException();
                    }

                    String empNumber = parts[0];
                    String firstName = parts[1];
                    String lastName = parts[2];

                    // Check if employee number is purely digits and no other characters.
                    if (!empNumber.matches("\\d+")) {
                        throw new IllegalArgumentException();
                    }

                    // Parsing the numbers.
                    
                    double hoursWorked = Double.parseDouble(parts[3]);
                    double hourlyWage = Double.parseDouble(parts[4]);

                    // Throws an exception if wage is too low (below 15.75) 
                    Employee emp = new Employee(empNumber, firstName, lastName, hoursWorked, hourlyWage);
                    employees[count++] = emp;

                } catch (Exception e) {
                	
          
                    if (errorCount == 0) {
                        System.out.println("> Error lines found in file payroll");
                        System.out.println();
                    }
                    System.out.println(line);
                    System.out.println();
                    errorWriter.println(line);
                    errorCount++;
                }
            }
            
            System.out.println();
            System.out.println("> " + (count + errorCount) + " lines read from file payroll");
            System.out.println();
            System.out.println("> " + errorCount + " lines written to error file");
            System.out.println();
            System.out.println("> Calculating deductions");
            System.out.println();
            System.out.println("> Writing report file");

            // Write's Report Header.. 
            reportWriter.println("iDroid Solutions");
            reportWriter.println("-------------------------------------------------------------------------------------------------------");
            reportWriter.printf("%-12s %-12s %-12s %15s %15s %15s%n",
                    "Employee", "First name", "Last Name", "Gross salary", "Deductions", "Net salary");
            reportWriter.println("-------------------------------------------------------------------------------------------------------");
            
            // Writes each employees dta.
            for (int i = 0; i < count; i++) {
                Employee emp = employees[i];

                double gross = emp.getGrossSalary();
                double deductions = emp.calculateTotalDeductions();
                double net = emp.calculateNetSalary();

                reportWriter.printf("%-12s %-12s %-12s $%9.2f   $%9.2f   $%9.2f%n",
                        emp.getEmployeeNumber(), emp.getFirstName(), emp.getLastName(),
                        gross, deductions, net);
            }

        } catch (FileNotFoundException e) {
        	
        	// print error if file not found.
        	
            System.out.println("File not found: payroll.txt");

        } finally {
        	
        	// as it is very necesarry to close all files.
            if (fileReader != null) fileReader.close();
            if (errorWriter != null) errorWriter.close();
            if (reportWriter != null) reportWriter.close();
        }
    }
}
