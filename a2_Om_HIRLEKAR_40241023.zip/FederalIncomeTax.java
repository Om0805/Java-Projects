//----------------------------------------------
//Assignment 2
//Written by: (Om Hirlekar - 40241023)
//For Comp 249 Section QQ - WINTER 2025
//----------------------------------------------

// for federal income tax, based on salaries of employees.
public class FederalIncomeTax extends Deductions {
	
	public FederalIncomeTax (double grossSalary) {
		super (grossSalary);
		
	}
	
	
	@Override
	
	public double calculateTax() {
		
		if(grossSalary < 16129) return 0;
		
		else if (grossSalary <= 57375) 
			
			return (grossSalary - 16129) * 0.15;
		
        else if (grossSalary <= 114750) 
        	
        	return (57375 - 16129) * 0.15 + (grossSalary - 57375) * 0.205;
		
        else if (grossSalary <= 177882) 
        	
        	return (57375 - 16129) * 0.15 + (114750 - 57375) * 0.205 + (grossSalary - 114750) * 0.26;
		
        else if (grossSalary <= 253414) 
        	
        	return (57375 - 16129) * 0.15 + (114750 - 57375) * 0.205 + (177882 - 114750) * 0.26 + (grossSalary - 177882) * 0.29;
		
        else 
        	return (57375 - 16129) * 0.15 + (114750 - 57375) * 0.205 + (177882 - 114750) * 0.26 + (253414 - 177882) * 0.29 + (grossSalary - 253414) * 0.33;
		
	}

}
