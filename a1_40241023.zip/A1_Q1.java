//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 248 Section H - Fall 2024
//----------------------------------------------

import java.util.Scanner;

public class A1_Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner (System.in);
		
		
		System.out.println("********Welcome to Solar Roof Energy Calculator*******");
		
		// Prompt the user for inputs
		System.out.print("Enter the number of solar panels: ");
		int numPanel = scan.nextInt();
		
		System.out.print("Enter the wattage rating of each solar panel (in watts): ");
		int panelWattage = scan.nextInt();
		
		System.out.print("Enter the average number of sunlight hours per day: ");
		double sunlightHours = scan.nextDouble();
		
		System.out.print("Enter the efficiency of the solar panels (as a percentage): ");
		double efficiency = scan.nextDouble();
		System.out.println();
		
		//constants
		int numDays = 365;
		
		// Calculate daily and annual energy production
		double dailyEnergyProduction = ((numPanel * panelWattage * sunlightHours * efficiency) / (1000 * 100));
		double annualEnergyProduction = ((numPanel * panelWattage * sunlightHours * efficiency) / (1000 * 100) * numDays );
		
		System.out.println("Daily Energy Production: " + dailyEnergyProduction + " " + "kWh");
		System.out.println("Annual Energy Production: " + annualEnergyProduction + " " + "kWh" );
		
		
		//Closing message
		System.out.println("Thank you for using the Solar Roof Energy Calculator!");
		
		scan.close();

		

	}

}

/*SAMPLE OUTPUT:
 * ********Welcome to Solar Roof Energy Calculator*******
Enter the number of solar panels: 10
Enter the wattage rating of each solar panel (in watts): 250
Enter the average number of sunlight hours per day: 6.0
Enter the efficiency of the solar panels (as a percentage): 20

Daily Energy Production: 3.0 kWh
Annual Energy Production: 1095.0 kWh
Thank you for using the Solar Roof Energy Calculator!
*/
