//----------------------------------------------
//Assignment 1
//Written by: (Om Hirlekar - 40241023)
//For Comp 248 Section H - Fall 2024
//----------------------------------------------

import java.util.Scanner;
public class A1_Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("*******Welcome To String Inspector*******");
		
		// Prompt the user for inputs
		System.out.print("Enter the given sentence (longer than 5 characters): ");
		String s1 = scan.nextLine();
		
		System.out.print("Enter the given word: ");
		String word = scan.next();
		
		System.out.print("Enter a separator to join the two strings: ");
		String separator = scan.next();
		
		
		System.out.println();
		
		// Check if the given word is contained in the sentence
		Boolean contains = s1.contains(word);
		System.out.println("Given sentence contains the given word: " + contains);
		
		// Check if the sentence starts with 'i'
		Boolean start = s1.startsWith("i");
		System.out.println("Given sentence starts with an 'i': " + start);
		
		// Replace 'a' with 'e' in the sentence

		String s2 = s1.replaceAll("a", "e");
		System.out.println("Sentence with 'a' replaced by 'e': " + s2);
		
        // Join sentence and word with the separator
		String s3 = String.join(separator,s1, word);
		System.out.println("Joined string: " + s3);		
		
		// Find the index of the first occurrence of 'a'
		int s4 = s1.indexOf('a');
		System.out.println("'a' appears at index " + s4 + " " + "in the given sentence.");
		
		// Print the character at the 3rd position (index 2)
		System.out.println("Character at 3rd position in the given sentence: " + s1.charAt(2));
		
		System.out.println();
		System.out.println("Thank you for using the String Inspector tool. Have a great day!");
		
		scan.close();

	}

}

/* SAMPLE OUTPUT:

*******Welcome To String Inspector*******
Enter the given sentence (longer than 5 characters): call a doctor 
Enter the given word: me
Enter a separator to join the two strings: 4

Given sentence contains the given word: false
Given sentence starts with an 'i': false
Sentence with 'a' replaced by 'e': cell e doctor 
Joined string: call a doctor 4me
'a' appears at index 1 in the given sentence.
Character at 3rd position in the given sentence: l

Thank you for using the String Inspector tool. Have a great day!
*/
